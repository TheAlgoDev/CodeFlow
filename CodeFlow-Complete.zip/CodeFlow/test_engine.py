import unittest
from unittest.mock import AsyncMock, patch
from engine import CASES, BioPortal, ai_assist, demo_annotations, validate_text, local_assist

class WorkflowTests(unittest.IsolatedAsyncioTestCase):
    async def test_bioportal_session_credentials_are_isolated(self):
        response = unittest.mock.Mock(status_code=200)
        response.json.return_value = {"acronym": "ICD10CM"}
        client = AsyncMock()
        client.get.return_value = response
        with patch.dict('os.environ', {}, clear=True), patch('engine.httpx.AsyncClient') as factory:
            factory.return_value.__aenter__.return_value = client
            connected = BioPortal(api_key='session-test-placeholder')
            await connected.request('/ontologies/ICD10CM')
            self.assertEqual(client.get.call_args.kwargs['headers']['Authorization'], 'apikey token=session-test-placeholder')
            with self.assertRaises(ValueError):
                await BioPortal().request('/ontologies/ICD10CM')

    async def test_local_context_and_history(self):
        response = unittest.mock.Mock(status_code=200)
        response.json.return_value = {"message": {"content": "Evidence-based explanation"}}
        client = AsyncMock()
        client.post.return_value = response
        with patch("engine.httpx.AsyncClient") as factory:
            factory.return_value.__aenter__.return_value = client
            answer = await local_assist("Explain selected tag", {"selected_tag": "historical pneumonia"},
                [{"role": "user", "content": "Previous question"}, {"role": "assistant", "content": "Previous answer"}], "Why reject it?")
        self.assertEqual(answer, "Evidence-based explanation")
        request = client.post.call_args
        self.assertEqual(request.args[0], "http://127.0.0.1:11434/api/chat")
        self.assertIn("historical pneumonia", request.kwargs["json"]["messages"][-1]["content"])
        self.assertEqual(request.kwargs["json"]["messages"][1]["content"], "Previous question")

    async def test_local_prompt_guard(self):
        with self.assertRaises(ValueError):
            await local_assist("", {}, [], "Explain")

    def test_offsets_and_context(self):
        text = CASES["Medication trap"]
        tags = demo_annotations(text, "ICD10")
        self.assertEqual(len({t["id"] for t in tags}), len(tags))
        for t in tags:
            self.assertEqual(text[t["start"]:t["end"]], t["phrase"])
        self.assertTrue(any(t["context"].startswith("Historical") for t in tags))
        self.assertTrue(any(t["context"].startswith("Negated") for t in tags))
        self.assertFalse(any(t["code"] == "E11.9" and t["context"].startswith("Current") for t in tags))
        self.assertTrue(all(t["context"].startswith("Current") for t in tags if t["code"] == "J20.9"))

    def test_input_guards(self):
        for text in ["", " " , "a" * 20001]:
            with self.assertRaises(ValueError):
                validate_text(text)

    async def test_live_annotation_offsets(self):
        client = BioPortal()
        client.request = AsyncMock(side_effect=[{}, [{"annotatedClass": {"@id": "urn:test/I10"}, "annotations": [{"from": 3, "to": 14}]}], {"prefLabel": "Hypertension"}])
        result = await client.annotate("  hypertension", "ICD10")
        self.assertEqual(result[0]["phrase"], "hypertension")
        self.assertEqual(result[0]["start"], 2)
        self.assertEqual(client.request.call_args_list[1].args[0], "/annotator")
        self.assertTrue(client.request.call_args_list[1].kwargs["post"])

    async def test_missing_credentials(self):
        with patch.dict("os.environ", {}, clear=True):
            with self.assertRaises(ValueError):
                await BioPortal().search("test", "ICD10")
            with self.assertRaises(ValueError):
                await ai_assist("Encounter", "synthetic", [], {}, True)

if __name__ == "__main__":
    unittest.main()
