"""Record six real local-model responses with identical notes and settings."""
import asyncio
import hashlib
import json
from datetime import datetime, timezone
import httpx
from engine import CASES, LOCAL_MODEL
from overview import COMPARISON_PATH, INITIAL_PROMPT, REFINED_PROMPT, COMPARISON_SYSTEM, COMPARISON_SCHEMA

async def main():
    data = {"schema_version": "1.0.0", "synthetic": True, "model": LOCAL_MODEL,
            "method": "Same note, model, options, system instruction and output schema; only task prompt changes. One run per version per note. Not a clinical accuracy evaluation.", "cases": []}
    async with httpx.AsyncClient(timeout=180, trust_env=False) as client:
        show = await client.post("http://127.0.0.1:11434/api/show", json={"model": LOCAL_MODEL})
        show.raise_for_status()
        data["model_details"] = show.json().get("details", {})
        for name,note in CASES.items():
            case = {"name": name, "note": note, "note_sha256": hashlib.sha256(note.encode("utf-8")).hexdigest(), "runs": {}}
            for version,prompt in [("initial", INITIAL_PROMPT), ("refined", REFINED_PROMPT)]:
                request = {"model": LOCAL_MODEL, "messages": [{"role": "system", "content": COMPARISON_SYSTEM},
                    {"role": "user", "content": prompt + "\n\nSYNTHETIC NOTE:\n" + note}],
                    "stream": False, "think": False, "format": COMPARISON_SCHEMA,
                    "options": {"temperature": 0.1, "num_ctx": 8192, "num_predict": 1200, "seed": 42}}
                started = datetime.now(timezone.utc).isoformat()
                response = await client.post("http://127.0.0.1:11434/api/chat", json=request)
                response.raise_for_status()
                raw = response.json()
                output = json.loads(raw["message"]["content"])
                if not isinstance(output.get("diagnoses"), list) or not isinstance(output.get("excluded_mentions"), list):
                    raise ValueError("Model returned an invalid comparison output.")
                case["runs"][version] = {"started_at": started, "completed_at": datetime.now(timezone.utc).isoformat(),
                                         "request": request, "response": raw, "output": output}
                print(f"Recorded {name}: {version}", flush=True)
            data["cases"].append(case)
    data["recorded_at"] = datetime.now(timezone.utc).isoformat()
    COMPARISON_PATH.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding="utf-8")
    print("Saved actual prompt comparison evidence.")

if __name__ == "__main__":
    asyncio.run(main())
