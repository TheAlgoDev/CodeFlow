import copy
import hashlib
import io
import json
import unittest
from zipfile import ZipFile
from engine import CASES, demo_annotations
from exports import build_outputs, render_report, output_package, codes_csv, validate_outputs
from pipeline import grounded_terms

def sample(**overrides):
    text = CASES['Medication trap']
    tags = demo_annotations(text, 'ICD10CM')
    reviews = {t['id']: {'decision': 'Accept' if t['code'] == 'J20.9' else 'Reject',
        'feedback': 'Documented bronchitis' if t['code'] == 'J20.9' else 'Not active for this encounter',
        'correction': '', 'timestamp': '2026-11-23T20:00:00+00:00'} for t in tags}
    args = dict(text=text, encounter_date='2026-11-23', ontology='ICD10CM', matching_mode='Offline demo',
        terms=grounded_terms(text, ['Metformin', 'acute bronchitis', 'pneumonia', 'Diabetes'], 'test'),
        tags=tags, reviews=reviews, audit={t['id']: {'recommendation': 'Keep' if t['code'] == 'J20.9' else 'Exclude', 'reason':'Teaching example'} for t in tags},
        list_audit={'summary':'List reviewed', 'issues':[]}, audit_current=True, first_listed='J20.9', finalized=True, blockers=[],
        acknowledgements={'agent_findings':True, 'unmatched_terms':True, 'final_coder_review':True}, coder_name='Demo coder', visit_comment='Reviewed against the patient file.', model='qwen3.5:2b')
    args.update(overrides)
    return args

class ExportTests(unittest.TestCase):
    def test_accepted_diagnoses_link_all_feedback(self):
        outputs = build_outputs(**sample())
        patient, feedback = outputs['patient_encoding'], outputs['coder_feedback']
        self.assertEqual(patient['review']['status'], 'review_complete')
        self.assertEqual(len(patient['diagnoses']), 1)
        self.assertEqual(len(patient['diagnoses'][0]['coder_feedback']), 2)
        self.assertEqual(len(feedback['annotation_reviews']), 5)
        self.assertEqual(patient['export'], feedback['export'])
        self.assertEqual(patient['counts']['rejected_occurrences'], 3)
        self.assertTrue(patient['unmatched_terms'])

    def test_correction_and_invalid_code_remain_honest(self):
        args = sample()
        for tag in args['tags']:
            if tag['code'] == 'J20.9':
                args['reviews'][tag['id']]['correction'] = '72929'
        patient = build_outputs(**args)['patient_encoding']
        self.assertFalse(patient['review']['review_complete'])
        diagnosis = patient['diagnoses'][0]
        self.assertEqual(diagnosis['coding']['code'], '72929')
        self.assertFalse(diagnosis['validation']['valid'])
        self.assertEqual(diagnosis['coding']['display'], 'Unverified code description')
        self.assertEqual(diagnosis['coder_feedback'][0]['original_coding']['code'], 'J20.9')

    def test_unreviewed_clarification_and_stale_audit(self):
        args = sample(audit_current=False)
        first = args['tags'][0]['id']
        args['reviews'][first]['decision'] = 'Needs clarification'
        args['reviews'].pop(args['tags'][1]['id'])
        patient = build_outputs(**args)['patient_encoding']
        self.assertEqual(patient['review']['status'], 'needs_clarification')
        self.assertFalse(patient['review']['review_complete'])
        self.assertEqual(patient['counts']['unreviewed_occurrences'], 1)

    def test_valid_correction_keeps_original_and_feedback(self):
        args = sample(first_listed='I10')
        for tag in args['tags']:
            if tag['code'] == 'J20.9':
                args['reviews'][tag['id']]['correction'] = 'I10'
        diagnosis = build_outputs(**args)['patient_encoding']['diagnoses'][0]
        self.assertEqual(diagnosis['coding']['code'], 'I10')
        self.assertTrue(diagnosis['validation']['valid'])
        self.assertEqual(diagnosis['coder_feedback'][0]['original_coding']['code'], 'J20.9')
        self.assertEqual(diagnosis['coder_feedback'][0]['replacement_coding']['code'], 'I10')
        # This checks data lineage, not clinical correctness of the replacement.

    def test_leading_zero_code_is_preserved_as_string(self):
        args = sample()
        for tag in args['tags']:
            if tag['code'] == 'J20.9':
                args['reviews'][tag['id']]['correction'] = '00100'
        code = build_outputs(**args)['patient_encoding']['diagnoses'][0]['coding']['code']
        self.assertEqual(code, '00100')
        self.assertIsInstance(code, str)

    def test_package_and_report_are_consistent_and_escape_text(self):
        outputs = build_outputs(**sample(visit_comment='<script>alert(1)</script>'))
        with ZipFile(io.BytesIO(output_package(outputs))) as archive:
            self.assertEqual(set(archive.namelist()), {'patient_encoding.json','coder_feedback.json','visit_report.html','codes.csv','manifest.json'})
            patient = json.loads(archive.read('patient_encoding.json'))
            feedback = json.loads(archive.read('coder_feedback.json'))
            manifest = json.loads(archive.read('manifest.json'))
            report = archive.read('visit_report.html').decode()
            self.assertIn(patient['export']['export_id'], report)
            self.assertEqual(patient['export'], feedback['export'])
            self.assertNotIn('<script>alert(1)</script>', report)
            self.assertIn('&lt;script&gt;alert(1)&lt;/script&gt;', report)
            for file in manifest['files']:
                self.assertEqual(file['sha256'], hashlib.sha256(archive.read(file['name'])).hexdigest())
            self.assertIn('Documented bronchitis', report)
            self.assertIn('Not active for this encounter', report)

    def test_version_changes_with_coder_feedback(self):
        a = build_outputs(**sample())['patient_encoding']
        b = build_outputs(**sample(visit_comment='Updated review'))['patient_encoding']
        self.assertEqual(a['visit_id'], b['visit_id'])
        self.assertNotEqual(a['export']['record_version'], b['export']['record_version'])

    def test_inconsistent_feedback_and_stale_spans_rejected(self):
        outputs = build_outputs(**sample())
        outputs['patient_encoding']['diagnoses'][0]['coder_feedback'] = [copy.deepcopy(outputs['patient_encoding']['diagnoses'][0]['coder_feedback'][0])]
        outputs['patient_encoding']['diagnoses'][0]['coder_feedback'][0]['rationale'] = 'Changed only in one document'
        with self.assertRaises(ValueError):
            validate_outputs(outputs)
        args = sample()
        args['tags'][0]['phrase'] = 'no longer matches'
        with self.assertRaises(ValueError):
            build_outputs(**args)

    def test_csv_formula_guard(self):
        args = sample()
        for review in args['reviews'].values():
            review['feedback'] = '=malicious_formula'
        csv = codes_csv(build_outputs(**args))
        self.assertIn("'=malicious_formula", csv)

if __name__ == '__main__':
    unittest.main()
