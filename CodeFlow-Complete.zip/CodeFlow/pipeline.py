"""Grounded term extraction and official code checks for the six-stage workflow."""
import json
import re
from datetime import date
from functools import lru_cache
from pathlib import Path
from zipfile import ZipFile
from engine import context, demo_annotations, local_assist

PROMPTS = [
    "Explain the synthetic patient file and the purpose of this visit. Quote evidence and identify missing information.",
    "Extract clinical condition, symptom and medication phrases exactly as written in the supplied file. Include historical and negated mentions. Do not infer diagnoses from medications. Return only the requested JSON.",
    "Explain candidate ontology matches, preferred labels, specificity, unmatched phrases and provenance. Use only supplied search metadata. Help the reviewer select a supported concept.",
    "Help review the selected occurrence. Compare its source evidence, context and candidate code. Explain support, uncertainty and missing specificity. The reviewer decides.",
    "MeSH concepts are enrichment only, never diagnosis codes. Audit the supplied tag against this visit and reviewer feedback. Recommend Keep, Exclude, or Clarify with a short evidence-based reason. Do not change the human decision. Return only the requested JSON.",
    "Explain the consolidated diagnosis codes, source evidence, first-listed selection, exclusions and unresolved items. A code-file match confirms existence and specificity, not clinical correctness or compliance.",
]

def grounded_terms(text, phrases, source):
    terms = {}
    for phrase in phrases:
        if not isinstance(phrase, str) or not phrase.strip():
            continue
        for match in re.finditer(re.escape(phrase.strip()), text, re.I):
            start, end = match.span()
            state, evidence = context(text, start, end)
            terms[(start, end)] = dict(id=f"term:{start}:{end}", start=start, end=end,
                phrase=match.group(), context=state, evidence=evidence, source=source)
    return sorted(terms.values(), key=lambda t: (t["start"], -t["end"]))

async def extract_terms(text, prompt, demo=False):
    if demo:
        phrases = [t["phrase"] for t in demo_annotations(text, "ICD10CM")] + ["Metformin", "Lisinopril", "cough"]
        return grounded_terms(text, phrases, "Demo extraction rules")
    schema = {"type": "object", "properties": {"terms": {"type": "array", "items": {"type": "string"}}}, "required": ["terms"]}
    result = json.loads(await local_assist(prompt, {"synthetic_text": text}, [], "Extract exact source phrases using the terms JSON schema.", schema))
    if not isinstance(result.get("terms"), list):
        raise ValueError("The model did not return a term list. Try again or add phrases manually.")
    return grounded_terms(text, result["terms"], "Local model · source-verified spans")

def filter_tags(tags, terms):
    return [t for t in tags if any(t["start"] < p["end"] and t["end"] > p["start"] for p in terms)]

@lru_cache(maxsize=1)
def code_catalog():
    path = Path(__file__).parent / "data" / "icd10cm-2027.zip"
    if not path.exists():
        return {}
    with ZipFile(path) as archive:
        text = archive.read("Code Descriptions/icd10cm_codes_2027.txt").decode("utf-8-sig")
    return {line[:7].strip(): line[8:].strip() for line in text.splitlines() if line.strip()}

def validate_code(code, encounter_date, ontology="ICD10CM"):
    if ontology != "ICD10CM":
        return {"valid": False, "message": "Use ICD-10-CM for the final diagnosis list."}
    try:
        visit_date = date.fromisoformat(str(encounter_date))
    except ValueError:
        return {"valid": False, "message": "Enter a valid encounter date."}
    if not date(2026, 10, 1) <= visit_date <= date(2027, 9, 30):
        return {"valid": False, "message": "Date is outside the loaded FY2027 code set."}
    catalog = code_catalog()
    if not catalog:
        return {"valid": False, "message": "Official code file is unavailable."}
    key = str(code).replace(".", "").upper().strip()
    if key not in catalog:
        return {"valid": False, "message": "Not a complete diagnosis code in the FY2027 file. Check specificity or correct the code."}
    return {"valid": True, "code": key[:3] + ("." + key[3:] if len(key) > 3 else ""),
            "description": catalog[key], "message": "Valid complete code · FY2027"}

def final_codes(tags, reviews, encounter_date, ontology):
    rows = {}
    for tag in tags:
        review = reviews.get(tag["id"], {})
        if tag.get("ontology", ontology) == "MESH" or review.get("decision") != "Accept":
            continue
        code = review.get("correction") or tag["code"]
        check = validate_code(code, encounter_date, ontology)
        key = code.replace(".", "").upper().strip()
        row = rows.setdefault(key, {"code": check.get("code", code), "description": check.get("description", tag["label"]),
                                    "validation": check, "evidence": [], "tag_ids": []})
        row["evidence"].append(tag["evidence"])
        row["tag_ids"].append(tag["id"])
    return list(rows.values())

async def audit_tag(text, tag, review, prompt, demo=False):
    if demo:
        recommendation = "Keep" if tag["context"].startswith("Current") else "Clarify"
        return {"recommendation": recommendation, "reason": "Demo rule: " + tag["context"] + ". Compare with provider documentation."}
    schema = {"type": "object", "properties": {"recommendation": {"type": "string", "enum": ["Keep", "Exclude", "Clarify"]},
              "reason": {"type": "string"}}, "required": ["recommendation", "reason"]}
    result = json.loads(await local_assist(prompt, {"synthetic_text": text, "tag": tag, "human_review": review}, [],
                       "Review this tag. Return recommendation and reason in JSON. Keep means the candidate appears supported, not final approval.", schema))
    if result.get("recommendation") not in ["Keep", "Exclude", "Clarify"] or not isinstance(result.get("reason"), str) or not result["reason"].strip():
        raise ValueError("Invalid agent audit response. Rerun the audit.")
    return result

async def audit_list(text, tags, reviews, rows, codes, prompt):
    ids = [t["id"] for t in tags]
    schema = {"type": "object", "properties": {
        "issues": {"type": "array", "items": {"type": "object", "properties": {
            "tag_id": {"type": "string", "enum": ids}, "explanation": {"type": "string"}},
            "required": ["tag_id", "explanation"]}}}, "required": ["issues"]}
    result = json.loads(await local_assist(prompt,
        {"synthetic_text": text, "candidate_decisions": [{"tag_id": t["id"], "code": t["code"], "phrase": t["phrase"],
            "ontology": t.get("ontology"), "human_decision": reviews.get(t["id"], {}), "per_tag_audit": rows.get(t["id"], {})} for t in tags],
         "actual_final_codes": [{"code": c["code"], "description": c["description"]} for c in codes]}, [],
        "Check for additional unresolved list inconsistencies. MeSH tags are biomedical enrichment and must never become final diagnosis codes. Accepted MeSH tags remain enrichment only. Rejected candidates stay in history but ARE NOT final codes. Repeated mentions are consolidated in actual_final_codes. A condition explicitly not assessed is NOT a missing diagnosis. Do not reverse completed per-tag findings without source evidence. Return only issues in the supplied JSON schema. Each issue must reference an existing tag_id. Do not list a correctly rejected candidate as an issue. Use an empty issues list if no further problem is established.", schema))
    if not isinstance(result.get("issues"), list):
        raise ValueError("Invalid whole-list audit response. Rerun the audit.")
    for issue in result["issues"]:
        if not isinstance(issue, dict) or issue.get("tag_id") not in ids or not isinstance(issue.get("explanation"), str):
            raise ValueError("The whole-list audit referenced an unknown tag. Rerun the audit.")
    result["summary"] = f"Compared {len(tags)} candidate occurrences with {len(codes)} consolidated visit codes. Agent comments below require human review."
    return result

def list_checks(tags, reviews, terms):
    findings = []
    groups = {}
    for tag in tags:
        if tag.get("ontology") == "MESH":
            continue
        groups.setdefault(tag["code"], []).append(tag)
    for code, group in groups.items():
        if len(group) > 1:
            findings.append(f"{code}: {len(group)} occurrences will be consolidated into one diagnosis if accepted.")
        if any(t["context"].startswith("Current") for t in group) and any(not t["context"].startswith("Current") for t in group):
            findings.append(f"{code}: mixed contexts; review each occurrence separately.")
    for tag in tags:
        if reviews.get(tag["id"], {}).get("decision") == "Accept" and not tag["context"].startswith("Current"):
            findings.append(f'{tag["code"]}: accepted despite a {tag["context"]} flag. Confirm the evidence.')
    unmatched = [t for t in terms if not any(t["start"] < p["end"] and t["end"] > p["start"] for p in tags if p.get("ontology") != "MESH")]
    if unmatched:
        findings.append("No code match for: " + ", ".join(dict.fromkeys(t["phrase"] for t in unmatched)) + ". These may be non-diagnosis terms or missed matches.")
    return findings
