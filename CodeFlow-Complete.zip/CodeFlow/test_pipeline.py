import unittest
from unittest.mock import patch, AsyncMock
from engine import CASES, demo_annotations
from pipeline import grounded_terms, filter_tags, final_codes, validate_code, audit_tag, audit_list, list_checks

class PipelineTests(unittest.IsolatedAsyncioTestCase):
    async def test_list_audit_rejects_unknown_tag_references(self):
        with patch('pipeline.local_assist', AsyncMock(return_value='{"summary":"Review","issues":[{"tag_id":"made-up","explanation":"problem"}]}')):
            with self.assertRaises(ValueError):
                await audit_list('test', [{'id':'known', 'code':'I10', 'phrase':'hypertension'}], {}, {}, [], 'audit')

    def test_grounding_discards_invented_terms(self):
        text = CASES['Medication trap']
        result = grounded_terms(text, ['pneumonia', 'invented diagnosis'], 'test')
        self.assertEqual(len(result), 2)
        self.assertTrue(all(text[t['start']:t['end']] == t['phrase'] for t in result))

    def test_complete_code_and_date(self):
        self.assertTrue(validate_code('j20.9', '2026-11-23')['valid'])
        self.assertFalse(validate_code('J45.9', '2026-11-23')['valid'])
        self.assertFalse(validate_code('I10', '2025-11-23')['valid'])
        self.assertFalse(validate_code('I10', '2026-11-23', 'ICD10')['valid'])

    def test_selection_and_final_deduplication(self):
        text = CASES['Medication trap']
        terms = grounded_terms(text, ['acute bronchitis'], 'test')
        tags = filter_tags(demo_annotations(text, 'ICD10CM'), terms)
        self.assertEqual(len(tags), 2)
        reviews = {t['id']: {'decision': 'Accept', 'correction': ''} for t in tags}
        rows = final_codes(tags, reviews, '2026-11-23', 'ICD10CM')
        self.assertEqual(len(rows), 1)
        self.assertEqual(len(rows[0]['tag_ids']), 2)
        reviews[tags[0]['id']]['correction'] = 'I10'
        self.assertEqual(len(final_codes(tags, reviews, '2026-11-23', 'ICD10CM')), 2)

    def test_unmatched_and_mixed_context(self):
        text = CASES['Medication trap']
        tags = demo_annotations(text, 'ICD10CM')
        terms = grounded_terms(text, ['Metformin'], 'test')
        findings = list_checks(tags, {}, terms)
        self.assertTrue(any('No code match' in f for f in findings))
        self.assertTrue(any('consolidated' in f for f in findings))

    async def test_audit_schema_validation(self):
        with patch('pipeline.local_assist', AsyncMock(return_value='{"recommendation":"Keep","reason":"Documented in assessment"}')):
            self.assertEqual((await audit_tag('test', {}, {}, 'audit'))['recommendation'], 'Keep')
        with patch('pipeline.local_assist', AsyncMock(return_value='{"recommendation":"invented","reason":"x"}')):
            with self.assertRaises(ValueError):
                await audit_tag('test', {}, {}, 'audit')
