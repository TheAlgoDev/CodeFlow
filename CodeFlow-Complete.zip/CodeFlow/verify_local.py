"""Manual smoke check against the actual local 2B model (not part of unit tests)."""
import asyncio
import json
from pathlib import Path
from pipeline import audit_list, PROMPTS

async def main():
    sample = json.loads(Path('sample-reviewed-visit.json').read_text(encoding='utf-8-sig'))
    result = await audit_list(sample['synthetic_text'], sample['tags'], sample['reviews'], sample['audit'], sample['coded_visit'], PROMPTS[4])
    Path('sample-list-audit.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    asyncio.run(main())
