/* The tour runs only in its own Shiny session; the host workspace is untouched. */
(() => {
  'use strict';
  const params = new URLSearchParams(location.search);
  const isTour = params.get('tour') === '1';
  const storageKey = 'codeflow-guided-tour-v1';
  const help = [
    ['Read the patient file', 'Start with the reason for the visit, assessment and plan. Medications and history provide context; they do not automatically establish current diagnoses.', 'Choose a teaching case, or expand “Edit or import synthetic text” to add a synthetic .txt file. Continue when you understand the encounter.'],
    ['Extract exact phrases', 'Extract terms proposes phrases from the source. Every retained phrase must actually appear in the patient file. The model can miss important information.', 'Keep the useful phrases selected. Add a missed phrase by copying the exact source text. Context flags are clues for review, not decisions.'],
    ['Match concepts, then inspect codes', 'A match links a phrase to an ontology concept and code. It does not mean the condition should be coded for this visit.', 'Connect BioPortal for live results. Check the code, description and source. Search alternatives if a phrase is unmatched or too broad.'],
    ['Your feedback decides', 'Review every occurrence against the quoted evidence. Accept a supported match, reject an unsupported one, or leave it for clarification.', 'Write a short reason and select “Save and review next.” You can correct a code. Rejected matches and explanations remain in the audit trail.'],
    ['Check the whole list', 'The agent reviews every tag and your feedback, then checks the consolidated list. It can be wrong and never overwrites your decisions.', 'Read the findings. Return to your review for corrections, then rerun the audit. Confirm that you have addressed its findings.'],
    ['Review the visit and its outputs', 'Accepted repeated mentions become one diagnosis code. The official file checks complete code identifiers for the date; human review still determines clinical appropriateness.', 'Choose the first-listed diagnosis, confirm your review and mark it complete. Download the JSON/feedback/report package, or preview the printable report.']
  ];
  let shell = null;
  let active = false;
  let paused = params.get('autostart') === '0';
  let skipDelay = false;
  let index = 0;
  let finished = false;
  let helpCoach = null;
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const visible = element => element && element.getClientRects().length > 0;
  const markSeen = () => { try { localStorage.setItem(storageKey, 'seen'); } catch (_) {} };
  const seen = () => { try { return localStorage.getItem(storageKey) === 'seen'; } catch (_) { return false; } };

  function openTour() {
    if (shell) return;
    if (helpCoach) helpCoach.remove();
    const url = new URL(location.href);
    url.search = '?tour=1';
    shell = document.createElement('div');
    shell.className = 'tour-shell';
    shell.innerHTML = '<iframe title="CodeFlow guided demonstration"></iframe><button type="button" class="tour-shell-exit">Return to my workspace</button>';
    shell.querySelector('iframe').src = url.href;
    shell.querySelector('button').onclick = closeTour;
    document.body.appendChild(shell);
  }
  function closeTour() {
    markSeen();
    if (shell) shell.remove();
    shell = null;
  }
  window.addEventListener('message', event => {
    if (event.origin === location.origin && shell && event.source === shell.querySelector('iframe').contentWindow && event.data === 'codeflow-tour-close') closeTour();
  });
  function exitTour() {
    active = false;
    markSeen();
    if (window.parent !== window) window.parent.postMessage('codeflow-tour-close', location.origin);
    else location.href = location.pathname;
  }
  function makeCoach() {
    const card = document.createElement('section');
    card.className = 'tour-coach';
    card.setAttribute('role', 'region');
    card.setAttribute('aria-label', 'Guided demonstration');
    card.innerHTML = '<div class="tour-eyebrow"></div><h3 tabindex="-1"></h3><p class="tour-body"></p><p class="tour-tip"></p><div class="tour-controls"><button type="button" data-action="pause">Pause</button><button type="button" data-action="next">Next</button><button type="button" class="secondary" data-action="exit">Skip tour</button></div><p class="tour-timing"></p><div class="tour-progress"><div></div></div>';
    document.body.appendChild(card);
    return card;
  }
  function showHelp(step) {
    if (isTour) return;
    if (helpCoach) helpCoach.remove();
    const card = makeCoach(); helpCoach = card;
    card.classList.add('help-only'); card.setAttribute('role', 'dialog');
    card.querySelector('.tour-eyebrow').textContent = `STEP ${step + 1} OF 6`;
    card.querySelector('h3').textContent = help[step][0];
    card.querySelector('.tour-body').textContent = help[step][1];
    card.querySelector('.tour-tip').textContent = help[step][2];
    card.querySelector('.tour-controls').innerHTML = '<button type="button">Got it</button>';
    card.querySelector('button').onclick = () => { card.remove(); helpCoach = null; };
    card.querySelector('h3').focus();
  }
  document.addEventListener('click', event => {
    const helpButton = event.target.closest('[data-step-help]');
    if (helpButton) showHelp(Number(helpButton.dataset.stepHelp));
    if (event.target.closest('#replay_tour') && !isTour) openTour();
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && helpCoach) { helpCoach.remove(); helpCoach = null; }
  });

  async function waitFor(test, timeout = 20000) {
    const started = Date.now();
    while (active) {
      if (test()) return;
      if (Date.now() - started > timeout) throw new Error('A demonstration result did not arrive. Replay the tour to try again.');
      await sleep(120);
    }
    throw new Error('Tour stopped');
  }
  function field(id, value) {
    const element = document.getElementById(id);
    if (!element) throw new Error(`Missing demonstration field: ${id}`);
    if (element.type === 'checkbox') element.checked = Boolean(value);
    else if (element.querySelector('input[type=radio]')) {
      const radio = [...element.querySelectorAll('input[type=radio]')].find(node => node.value === value);
      if (!radio) throw new Error('Missing review choice');
      radio.checked = true;
    } else element.value = value;
    element.dispatchEvent(new Event('input', {bubbles:true}));
    element.dispatchEvent(new Event('change', {bubbles:true}));
    window.Shiny.setInputValue(id, value, {priority:'event'});
  }
  async function click(selector) {
    await waitFor(() => visible(document.querySelector(selector)));
    const element = document.querySelector(selector);
    element.scrollIntoView({block:'center', behavior:'smooth'});
    element.classList.add('tour-clicking');
    await sleep(600);
    element.click();
    await sleep(450);
    element.classList.remove('tour-clicking');
  }
  async function tab(number) {
    await click(`[data-bs-toggle="tab"][data-value="${number}"]`);
    window.scrollTo({top:0, behavior:'smooth'});
  }
  function highlight(selector) {
    document.querySelectorAll('.tour-focus').forEach(element => element.classList.remove('tour-focus'));
    const element = document.querySelector(selector);
    if (element) { element.classList.add('tour-focus'); element.scrollIntoView({block:'center', behavior:'smooth'}); }
  }
  async function hold(seconds) {
    let remaining = seconds * 1000;
    while (active && remaining > 0) {
      if (skipDelay) { skipDelay = false; break; }
      await sleep(150);
      if (!paused) remaining -= 150;
    }
  }
  async function review(decision, rationale) {
    field('decision', decision); field('feedback', rationale);
    await sleep(600);
    highlight('#review_evidence');
  }
  async function saveReview(count) {
    await click('#save_review');
    await waitFor(() => (document.querySelector('#review_progress')?.textContent || '').startsWith(`${count} of 5`));
    await sleep(450);
  }

  async function startTour() {
    document.body.classList.add('tour-mode');
    const banner = document.createElement('div'); banner.className = 'tour-banner';
    banner.textContent = 'GUIDED DEMO · Synthetic example · Scripted matches and agent results · No live services';
    document.body.appendChild(banner);
    const card = makeCoach(); active = true;
    const pauseButton = card.querySelector('[data-action=pause]');
    const timing = card.querySelector('.tour-timing');
    const syncPause = () => { pauseButton.textContent = paused ? 'Play' : 'Pause'; timing.textContent = paused ? 'Paused. Play to continue automatically, or Next to advance.' : 'Advances slowly. Pause at any time to read.'; };
    card.querySelector('.tour-eyebrow').textContent='GUIDED DEMO';
    card.querySelector('h3').textContent='Patient text to reviewed codes';
    card.querySelector('.tour-body').textContent='Watch the software walk through a separate synthetic example.';
    card.querySelector('.tour-tip').textContent='Press Play to start. Pause, Next and Skip are always available.';
    pauseButton.onclick = () => { paused = !paused; syncPause(); };
    card.querySelector('[data-action=next]').onclick = () => { skipDelay = true; };
    card.querySelector('[data-action=exit]').onclick = exitTour;
    const steps = [
      {title:'From patient text to reviewed codes', body:'Watch a complete synthetic visit move through all six stages. The software will click and enter example decisions for you.', tip:'This demonstration uses a separate session. Your patient file, feedback and BioPortal key in the workspace are untouched.', seconds:9, action:async()=>{
        const toggle = document.querySelector('.bslib-sidebar-layout > .collapse-toggle');
        if (toggle && toggle.getAttribute('aria-expanded') === 'true') toggle.click();
        field('bio_mode','Offline demo'); field('ai_mode','Demo rules'); field('ontology','ICD10CM');
        field('case','Medication trap'); field('coder_name','Presentation demo (scripted)'); await sleep(500);
      }},
      {title:'1. Read the visit', body:'The patient is seen for cough. Acute bronchitis is documented. Metformin is listed, and an old pneumonia diagnosis is resolved.', tip:'The key question is what the provider documented for this encounter—not which conditions appear anywhere in the chart.', seconds:10, action:async()=>{await tab(0); highlight('#patient_chart');}},
      {title:'2. Extract source phrases', body:'Click Extract terms to identify clinical phrases and their location in the text. In normal use, the local 2B model proposes them and the app verifies the source spans.', tip:'Here, labeled demo rules produce predictable phrases so the presentation does not depend on model speed.', seconds:8, action:async()=>{await tab(1); await click('#extract'); await waitFor(()=>document.querySelectorAll('#selected_terms input').length > 0); highlight('#term_picker');}},
      {title:'Check what was found', body:'Current, historical, negated and medication mentions are different. A missed phrase can be added by copying it from the chart.', tip:'Selection controls what gets matched. The context labels help you review; they are not final coding decisions.', seconds:8, action:async()=>{highlight('#term_picker');}},
      {title:'3. Match phrases to code candidates', body:'The matching step highlights source text and pairs it with a code and description. Live BioPortal can annotate, search terms, show synonyms and explore related concepts.', tip:'These are curated demo matches, not a live BioPortal response. A candidate code still needs coder review.', seconds:9, action:async()=>{await tab(2); await click('#annotate'); await waitFor(()=>document.querySelector('#match_status')?.textContent.includes('5 candidate')); highlight('#highlighted');}},
      {title:'Make sense of unmatched phrases', body:'Cough and metformin remain unmatched in this small teaching vocabulary. In live mode, search alternatives and inspect the actual ontology source.', tip:'An unmatched medication does not need to become a diagnosis. Broader matching can also add noise; inspect each candidate.', seconds:8, action:async()=>{highlight('#matches');}},
      {title:'4. Reject historical carry-forward', body:'This pneumonia mention describes a resolved past infection. The example coder rejects it and records why.', tip:'Feedback belongs to each occurrence. The source phrase and your reason remain available in the final audit and report.', seconds:8, action:async()=>{await tab(3); await review('Reject','Resolved pneumonia is historical and is not active in this visit.');}},
      {title:'Accept the documented assessment', body:'Acute bronchitis is explicitly documented in the assessment. The example coder accepts this supported occurrence.', tip:'Accepting a match is a human decision. The agent never silently accepts codes for you in the real workspace.', seconds:8, action:async()=>{await saveReview(1); await review('Accept','Acute bronchitis is explicitly documented in the current assessment.');}},
      {title:'Reject a negated condition', body:'The same chart also says “No evidence of pneumonia.” A lexical match still finds pneumonia, but the coder excludes this negated occurrence.', tip:'This is why matching a word is different from deciding that the diagnosis should be reported.', seconds:8, action:async()=>{await saveReview(2); await review('Reject','The provider explicitly states no evidence of pneumonia.');}},
      {title:'Keep evidence, consolidate duplicates', body:'The plan repeats acute bronchitis. The coder accepts this second piece of evidence; the final visit will contain one bronchitis code, not two.', tip:'Occurrence-level feedback is preserved even when the final code list is deduplicated.', seconds:7, action:async()=>{await saveReview(3); await review('Accept','The treatment plan supports the same bronchitis diagnosis; consolidate the repeated code.');}},
      {title:'Do not infer a diagnosis from medication', body:'Diabetes is not assessed during this visit. Metformin alone does not establish the diagnosis for this encounter, so the example coder rejects the suggestion.', tip:'After reviewing all matches, check unmatched phrases and address any missing diagnosis matches.', seconds:9, action:async()=>{await saveReview(4); await review('Reject','Diabetes is not assessed in this visit. Metformin alone does not establish a reportable diagnosis.');}},
      {title:'5. Audit every tag and the list', body:'The agent checks each tag alongside coder feedback, then checks the consolidated list. Your decisions remain authoritative.', tip:'This tour uses demo rules. With the local model, audit recommendations can be wrong and still require your review.', seconds:10, action:async()=>{await saveReview(5); field('unmatched_ack',true); await tab(4); await click('#audit'); await waitFor(()=>document.querySelector('#audit_status')?.textContent.includes('Audit complete')); highlight('#audit_output');}},
      {title:'6. Review the coded visit', body:'The accepted bronchitis mentions become one code: J20.9. The official FY2027 code file confirms the complete identifier for the encounter date.', tip:'A valid identifier does not prove clinical appropriateness, sequencing or reportability. The coder completes those checks.', seconds:10, action:async()=>{field('audit_ack',true); await tab(5); await waitFor(()=>document.querySelector('#first_code option[value="J20.9"]')); field('first_code','J20.9'); field('visit_comment','Scripted synthetic demonstration: bronchitis accepted; unsupported pneumonia and diabetes suggestions excluded.'); field('coder_confirm',true); await sleep(600); await click('#finalize'); await waitFor(()=>document.querySelector('#final_status')?.textContent.includes('Visit review complete')); highlight('#coded_visit');}},
      {title:'The JSON keeps the evidence and feedback', body:'Patient encoding JSON includes ordered codes, source evidence and linked coder rationales. The separate feedback JSON also retains rejected, corrected and unresolved matches.', tip:'Both files and the report share the same visit ID, version and export ID. Draft exports stay labeled as drafts.', seconds:9, action:async()=>{const node=document.querySelector('#encoding_preview'); for(let d=node?.closest('details');d;d=d.parentElement?.closest('details')) d.open=true; highlight('#encoding_preview');}},
      {title:'Generate a readable visit report', body:'The report uses the same data as the JSON: accepted codes, coder feedback, exclusions, agent findings and outstanding questions.', tip:'Use Print / save PDF in the report. Download output package includes both JSON files, report, CSV and a checksum manifest.', seconds:10, action:async()=>{document.querySelectorAll('details').forEach(node=>node.open=false); await click('#preview_report'); await waitFor(()=>document.querySelector('#report_frame'));}},
      {title:'Ready to try your own synthetic visit', body:'The demonstration is complete. Return to your workspace to connect BioPortal, use the local model, and make your own review decisions.', tip:'Every page has “How this step works.” You can replay this demonstration at any time using “Watch guided demo.”', seconds:0, action:async()=>{const close=[...document.querySelectorAll('.modal button')].find(node=>node.textContent.includes('Close report')); if(close) close.click(); await sleep(500); highlight('#package_download');}}
    ];
    syncPause();
    try {
      for (index=0; index<steps.length && active; index++) {
        while (paused && !skipDelay && active && index===0) await sleep(150);
        skipDelay=false;
        const step=steps[index];
        card.querySelector('.tour-eyebrow').textContent=`GUIDED DEMO · ${index+1} / ${steps.length}`;
        card.querySelector('h3').textContent=step.title;
        card.querySelector('.tour-body').textContent=step.body;
        card.querySelector('.tour-tip').textContent=step.tip;
        card.querySelector('.tour-progress div').style.width=`${(index+1)/steps.length*100}%`;
        await step.action();
        if(index<steps.length-1) await hold(step.seconds);
      }
      if(!active) return;
      finished=true; markSeen();
      card.querySelector('.tour-controls').innerHTML='<button type="button" data-finish>Use my workspace</button><button type="button" class="secondary" data-replay>Replay</button>';
      card.querySelector('[data-finish]').onclick=exitTour;
      card.querySelector('[data-replay]').onclick=()=>location.reload();
      timing.textContent='Tour complete · No live requests were made.';
    } catch(error) {
      if(!active) return;
      card.querySelector('h3').textContent='The demo paused';
      card.querySelector('.tour-body').textContent=error.message;
      card.querySelector('.tour-tip').textContent='Your workspace is unchanged. Return to it or replay the isolated demonstration.';
      card.querySelector('.tour-controls').innerHTML='<button type="button" data-finish>Use my workspace</button><button type="button" data-replay>Replay</button>';
      card.querySelector('[data-finish]').onclick=exitTour;
      card.querySelector('[data-replay]').onclick=()=>location.reload();
      timing.textContent='Not completed';
    }
  }

  function connected() {
    if (window.__codeflowTourInitialized) return;
    window.__codeflowTourInitialized=true;
    if(isTour) startTour();
    else if(!seen()) setTimeout(openTour,1000);
  }
  function initialize() {
    if(window.jQuery) window.jQuery(document).on('shiny:connected.codeflowTour',connected);
    if(window.Shiny?.shinyapp?.$socket?.readyState===1) connected();
    else if(!window.jQuery) setTimeout(initialize,100);
  }
  initialize();
})();
