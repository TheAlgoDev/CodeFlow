import asyncio
import json
import os
from datetime import datetime, timezone
from html import escape
from pathlib import Path
import httpx
from shiny import App, reactive, render, ui
from engine import CASES, TERMS, BioPortal, LOCAL_MODEL, local_assist, demo_annotations, demo_mesh_annotations, validate_text
from pipeline import PROMPTS, extract_terms, grounded_terms, filter_tags, audit_tag, audit_list, list_checks, final_codes
from exports import build_outputs, render_report, output_package, codes_csv
from overview import overview_panel, COMPARISON_PATH

STEPS = ["Patient file", "Extract terms", "Match codes", "Your review", "Agent audit", "Coded visit"]

def assistant(index):
    return ui.tags.details(ui.tags.summary("Ask the local assistant"),
        ui.input_action_button(f"explain_{index}", "Explain this step"),
        ui.input_action_button(f"prompt_{index}", "Edit agent prompt"),
        ui.input_action_button(f"clear_{index}", "Clear chat"),
        ui.output_ui(f"chat_{index}"),
        ui.input_text_area(f"question_{index}", "Your question", rows=2, width="100%"),
        ui.input_action_button(f"send_{index}", "Ask", class_="btn-primary"),
        ui.p("Compare model explanations with the source; a small model can add unsupported details."),
        ui.tags.details(ui.tags.summary("View context"), ui.tags.pre(ui.output_text(f"context_{index}"))))

def page(index, title, subtitle, *content):
    return ui.nav_panel(f"{index+1} · {STEPS[index]}", ui.h2(title), ui.p(subtitle, class_="subtitle"),
        ui.tags.button("How this step works", type="button", class_="btn btn-outline-secondary step-help", **{"data-step-help": str(index)}),
        *content, assistant(index),
        ui.div(*([ui.input_action_button(f"back_{index}", "Back")] if index else []),
               *([ui.input_action_button(f"next_{index}", "Continue", class_="btn-primary")] if index < 5 else []), class_="step-footer"), value=str(index))

app_ui = ui.page_fluid(
    ui.tags.head(ui.tags.link(rel="stylesheet", href="style.css"), ui.tags.link(rel="stylesheet", href="chat.css"), ui.tags.link(rel="stylesheet", href="workflow.css"),
        ui.tags.link(rel="stylesheet", href="tour.css"), ui.tags.script(src="tour.js", defer=True)),
    ui.div(ui.div(ui.span("+", class_="brand-icon"), ui.div(ui.h1("CodeFlow"), ui.span("PATIENT FILE TO REVIEWED CODES"))), ui.span("SYNTHETIC DATA", class_="pill"), class_="masthead"),
    ui.layout_sidebar(ui.sidebar(
        ui.h4("Visit workspace"), ui.input_select("case", "Teaching case", list(CASES)),
        ui.tags.button("Watch guided demo", type="button", id="replay_tour", class_="btn btn-outline-primary"),
        ui.input_action_button("load", "Open patient file"), ui.output_ui("progress"),
        ui.h4("BioPortal connection"),
        ui.input_password("bioportal_key", "BioPortal API key", placeholder="Enter your API key"),
        ui.input_action_button("connect_bioportal", "Connect", class_="btn-primary"),
        ui.output_text("bioportal_connection"),
        ui.p("Kept only for this session. Excluded from exports and assistant context."),
        ui.tags.details(ui.tags.summary("Patient file"), ui.output_ui("source_sidebar")),
        ui.tags.details(ui.tags.summary("Settings"),
            ui.input_select("bio_mode", "Term matching", ["Live BioPortal", "Offline demo"], selected="Live BioPortal" if os.getenv("BIOPORTAL_API_KEY") else "Offline demo"),
            ui.input_select("ontology", "Vocabulary", {"ICD10CM": "ICD-10-CM (diagnosis coding)", "ICD10": "ICD-10 (exploration)"}),
            ui.input_select("ai_mode", "Assistant", ["Local 2B · Ollama", "Demo rules"], selected="Demo rules" if os.getenv("CODEFLOW_DEMO") == "1" else "Local 2B · Ollama"),
            ui.p(LOCAL_MODEL), ui.p("Live annotation sends synthetic text to BioPortal.")),
        ui.p("Synthetic outpatient diagnosis coding demo. Save an export before closing."), width=265),
        ui.navset_tab(
            overview_panel(),
            page(0, "Start with the patient", "Read the visit, then continue to find its clinical terms.",
                ui.output_ui("patient_chart"),
                ui.tags.details(ui.tags.summary("Edit or import synthetic text"),
                    ui.input_file("upload", "Open a synthetic .txt file", accept=[".txt"]),
                    ui.input_date("visit_date", "Encounter date", value="2026-11-23"),
                    ui.input_text_area("note", "Patient record", CASES["Medication trap"], width="100%", rows=12),
                    ui.p("Changing the source clears terms, matches, feedback and audit results.")),
                ui.download_button("patient_download", "Download synthetic patient file")),
            page(1, "Find the clinical terms", "Extract phrases from the chart. Keep the ones you want to match; add anything missed.",
                ui.input_action_button("extract", "Extract terms", class_="btn-primary"), ui.output_text("extract_status"),
                ui.output_ui("term_picker"), ui.output_ui("term_table"),
                ui.tags.details(ui.tags.summary("Add a missed phrase"), ui.input_text("manual_phrase", "Exact phrase from the patient file"), ui.input_action_button("add_phrase", "Add phrase"))),
            page(2, "Match terms to codes", "Match selected phrases, inspect the evidence, and search for alternatives when needed.",
                ui.input_checkbox("mesh_enrichment", "Enrich with MeSH biomedical concepts", value=False),
                ui.p("MeSH adds research terminology. Review these tags separately from diagnosis codes."),
                ui.output_text("match_mode"), ui.input_action_button("annotate", "Match selected terms", class_="btn-primary"), ui.output_text("match_status"),
                ui.card(ui.card_header("PATIENT TEXT"), ui.output_ui("highlighted")), ui.output_ui("matches"),
                ui.tags.details(ui.tags.summary("Find or refine a match in BioPortal"),
                    ui.input_select("search_ontology", "Search vocabulary", {"ICD10CM": "ICD-10-CM", "ICD10": "ICD-10", "MESH": "MeSH biomedical concepts"}),
                    ui.input_select("search_term", "Source phrase", {}), ui.input_text("query", "Search term or code"),
                    ui.input_action_button("search", "Search"), ui.input_select("concept", "Candidate concept", {}),
                    ui.input_select("relation", "Explore", {"": "Label, synonyms, definition", "parents": "Parents", "children": "Children", "mappings": "Mappings"}),
                    ui.input_action_button("inspect", "Inspect concept"), ui.output_ui("concept_detail"),
                    ui.input_action_button("add_match", "Add candidate for this phrase"))),
            page(3, "Review each match", "Accept, exclude or question each occurrence. Save feedback to move to the next one.",
                ui.tags.details(ui.tags.summary("Coder details (optional)"), ui.input_text("coder_name", "Coder name / label"), ui.p("Self-reported label; this is not an authenticated signature.")),
                ui.output_text("review_progress"), ui.input_select("tag", "Match to review", {}),
                ui.output_ui("review_evidence"),
                ui.input_radio_buttons("decision", "Your decision", ["Accept", "Reject", "Needs clarification"], selected="Needs clarification", inline=True),
                ui.input_text_area("feedback", "Why?", rows=2, width="100%"),
                ui.tags.details(ui.tags.summary("Correct the code"), ui.input_text("correction", "Replacement ICD-10-CM code")),
                ui.input_action_button("save_review", "Save and review next", class_="btn-primary"), ui.output_ui("review_log"),
                ui.input_checkbox("unmatched_ack", "I checked unmatched phrases and addressed any missing diagnosis matches.")),
            page(4, "Ask the agent to check the list", "The local model checks every match, then reviews the list for inconsistencies. Your decisions stay in place.",
                ui.input_action_button("audit", "Check all tags", class_="btn-primary"), ui.output_text("audit_status"),
                ui.output_ui("audit_output"), ui.input_checkbox("audit_ack", "I reviewed the agent findings and resolved or documented the issues.")),
            page(5, "See the coded visit", "One consolidated diagnosis list, with evidence and remaining questions.",
                ui.input_select("first_code", "First-listed diagnosis (choose after review)", {}), ui.output_ui("coded_visit"),
                ui.input_text_area("visit_comment", "Overall coder feedback (optional)", rows=2, width="100%"),
                ui.input_checkbox("coder_confirm", "I reviewed the visit, code order and supporting documentation."),
                ui.input_action_button("finalize", "Mark review complete", class_="btn-primary"), ui.output_text("final_status"),
                ui.card(ui.card_header("PATIENT CODING OUTPUTS"), ui.output_ui("export_summary"),
                    ui.download_button("package_download", "Download output package", class_="btn-primary"),
                    ui.input_action_button("preview_report", "Preview report"),
                    ui.download_button("report_download", "Download visit report"),
                    ui.tags.details(ui.tags.summary("JSON, CSV and preview"),
                        ui.download_button("audit_download", "Patient encoding JSON"),
                        ui.download_button("feedback_download", "Coder feedback JSON"),
                        ui.download_button("codes_download", "Codes CSV"),
                        ui.tags.details(ui.tags.summary("Patient encoding preview"), ui.tags.pre(ui.output_text("encoding_preview"))),
                        ui.tags.details(ui.tags.summary("Coder feedback preview"), ui.tags.pre(ui.output_text("feedback_preview")))))),
            id="workflow", selected="overview")), title="CodeFlow | Patient coding workflow")

def server(input, output, session):
    terms, tags, reviews = reactive.Value([]), reactive.Value([]), reactive.Value({})
    term_selection = reactive.Value([])
    search_items, metadata = reactive.Value([]), reactive.Value(None)
    audit_rows, audit_summary = reactive.Value({}), reactive.Value("")
    audit_snapshot = reactive.Value(None)
    finalized = reactive.Value(None)
    messages = {k: reactive.Value("") for k in ["extract", "match", "audit", "final"]}
    prompts = [reactive.Value(p) for p in PROMPTS]
    chats = [reactive.Value([]) for _ in STEPS]
    chat_status = [reactive.Value("") for _ in STEPS]
    editing_prompt = reactive.Value(None)
    tasks, running = set(), set()
    bp = BioPortal()
    connection_status = reactive.Value("Server key configured" if os.getenv("BIOPORTAL_API_KEY") else "Not connected · offline demo available")
    generation = [0]
    session.on_ended(lambda: [task.cancel() for task in list(tasks)])

    def error(exc):
        ui.notification_show(str(exc) or "The service request failed. Try again.", type="error", duration=8)

    def snapshot():
        return json.dumps({"text": input.note(), "date": str(input.visit_date()), "ontology": input.ontology(),
            "mode": input.bio_mode(), "mesh_enrichment": input.mesh_enrichment(), "assistant": input.ai_mode(), "terms": chosen_terms(), "tags": tags(), "reviews": reviews(), "audit_prompt": prompts[4]()}, sort_keys=True)

    def chosen_terms():
        selected = term_selection()
        return [t for t in terms() if t["id"] in selected]

    def spawn(name, work):
        if name in running:
            return error(ValueError("This action is still running."))
        running.add(name)
        async def guarded():
            try:
                await work()
            except (ValueError, httpx.HTTPError, KeyError, TypeError) as exc:
                with reactive.isolate():
                    target = name if name in messages else None
                    if target:
                        messages[target].set("Could not finish: " + (str(exc) or type(exc).__name__))
                    if name.startswith("chat-"):
                        chat_status[int(name.split("-")[1])].set("Could not answer. Check Ollama and try again.")
                    error(exc)
            finally:
                running.discard(name)
        task = asyncio.create_task(guarded())
        tasks.add(task)
        task.add_done_callback(tasks.discard)

    def clear_matches():
        tags.set([]); reviews.set({}); audit_rows.set({}); audit_summary.set(""); audit_snapshot.set(None); finalized.set(None)
        ui.update_select("tag", choices={}); ui.update_checkbox("audit_ack", value=False); ui.update_checkbox("coder_confirm", value=False); ui.update_checkbox("unmatched_ack", value=False)

    def update_tag_choices(selected=None):
        ui.update_select("tag", choices={t["id"]: f'{t["phrase"]} · {t["code"]} · occurrence {i+1}' for i,t in enumerate(tags())}, selected=selected)

    @render.text
    def bioportal_connection():
        return connection_status()

    @reactive.effect
    @reactive.event(input.connect_bioportal)
    def connect_bioportal():
        if "connect" in running:
            return error(ValueError("Connection check is still running."))
        entered = input.bioportal_key().strip()
        if not entered:
            return error(ValueError("Enter a BioPortal API key first."))
        if len(entered) > 512 or any(character.isspace() for character in entered):
            return error(ValueError("Check the API key: remove spaces and line breaks."))
        candidate = BioPortal(api_key=entered)
        ui.update_text("bioportal_key", value="")
        connection_status.set("Checking connection…")
        async def work():
            nonlocal bp
            try:
                await candidate.request("/ontologies/ICD10CM")
            except (ValueError, httpx.HTTPError):
                connection_status.set("Connection failed. Check the key, network and ICD-10-CM access, then try again.")
                return
            with reactive.isolate():
                bp = candidate
                generation[0] += 1
                clear_matches(); search_items.set([]); metadata.set(None)
                connection_status.set("Connected · ICD-10-CM available")
                ui.update_select("bio_mode", selected="Live BioPortal")
        spawn("connect", work)

    @reactive.effect
    def source_changed():
        input.note(); input.visit_date(); input.ontology(); input.bio_mode(); input.mesh_enrichment()
        generation[0] += 1
        terms.set([]); term_selection.set([]); clear_matches(); search_items.set([]); metadata.set(None)
        ui.update_select("concept", choices={})
        for chat in chats:
            chat.set([])
        for message in messages.values():
            message.set("")

    @reactive.effect
    @reactive.event(input.load)
    def load():
        ui.update_text_area("note", value=CASES[input.case()])
        ui.update_navset("workflow", selected="0")

    @reactive.effect
    @reactive.event(input.upload)
    def upload():
        try:
            files = input.upload()
            if not files:
                return
            if files[0]["size"] > 80000 or not files[0]["name"].lower().endswith(".txt"):
                raise ValueError("Open a synthetic UTF-8 .txt file smaller than 80 KB.")
            text = Path(files[0]["datapath"]).read_text(encoding="utf-8-sig")
            validate_text(text)
            ui.update_text_area("note", value=text)
        except (ValueError, OSError) as exc:
            error(exc)

    @render.ui
    def patient_chart():
        return ui.card(ui.card_header("SYNTHETIC OUTPATIENT RECORD"), ui.p("Encounter date: " + str(input.visit_date())),
            *[ui.div(ui.strong(line.split(":", 1)[0]), ui.p(line.split(":", 1)[1])) if ":" in line else ui.p(line) for line in input.note().splitlines() if line.strip()])

    @render.ui
    def source_sidebar():
        return ui.div(input.note(), class_="clinical-text")

    @render.ui
    def progress():
        return ui.div(ui.p(f"{len(chosen_terms())} phrases · {len(tags())} matches"), ui.p(f"{len(reviews())} of {len(tags())} reviewed"),
                      ui.span(input.bio_mode(), class_="badge-note"))

    @reactive.effect
    @reactive.event(input.extract)
    def extract():
        text, prompt, demo, version = input.note(), prompts[1](), input.ai_mode() == "Demo rules", generation[0]
        try:
            validate_text(text)
        except ValueError as exc:
            return error(exc)
        messages["extract"].set("Finding exact phrases in the patient file…")
        async def work():
            result = await extract_terms(text, prompt, demo)
            with reactive.isolate():
                if generation[0] != version or prompts[1]() != prompt:
                    return
                clear_matches(); terms.set(result); term_selection.set([t["id"] for t in result])
                messages["extract"].set(f"Found {len(result)} source phrases. Review the selection below.")
        spawn("extract", work)

    @render.text
    def extract_status():
        return messages["extract"]()

    @render.ui
    def term_picker():
        if not terms():
            return ui.p("Extract terms to begin. You can also add an exact phrase manually.")
        return ui.input_checkbox_group("selected_terms", "Phrases to match", {t["id"]: f'{t["phrase"]} · {t["context"]}' for t in terms()}, selected=term_selection())

    @reactive.effect
    @reactive.event(input.selected_terms)
    def select_terms():
        selected = list(input.selected_terms() or [])
        if selected != term_selection():
            term_selection.set(selected); clear_matches()

    @render.ui
    def term_table():
        return ui.tags.details(ui.tags.summary("See source evidence"), *[ui.div(ui.strong(t["phrase"]), ui.p(t["evidence"])) for t in chosen_terms()])

    @reactive.effect
    @reactive.event(input.add_phrase)
    def add_phrase():
        phrase = input.manual_phrase().strip()
        if len(phrase) < 2:
            return error(ValueError("Enter at least two characters copied from the patient file."))
        additions = grounded_terms(input.note(), [phrase], "Added by reviewer")
        if not additions:
            return error(ValueError("That phrase does not appear in the source text."))
        combined = {t["id"]: t for t in terms() + additions}
        terms.set(sorted(combined.values(), key=lambda t:t["start"]))
        term_selection.set(list(dict.fromkeys(term_selection() + [t["id"] for t in additions])))
        clear_matches()

    @reactive.effect
    def source_phrase_choices():
        ui.update_select("search_term", choices={t["id"]: f'{t["phrase"]} · character {t["start"]+1}' for t in chosen_terms()})

    @reactive.effect
    @reactive.event(input.search_term)
    def populate_query():
        phrase = next((t for t in terms() if t["id"] == input.search_term()), None)
        if phrase:
            ui.update_text("query", value=phrase["phrase"])

    @reactive.effect
    @reactive.event(input.search_ontology)
    def clear_search():
        generation[0] += 1
        search_items.set([]); metadata.set(None)
        ui.update_select("concept", choices={})

    @render.text
    def match_mode():
        return "Live BioPortal annotation and search" if input.bio_mode() == "Live BioPortal" else "Offline demo: curated examples. Open Settings to connect live BioPortal."

    @reactive.effect
    @reactive.event(input.annotate)
    def annotate():
        text, selected, ontology, mode, version = input.note(), chosen_terms(), input.ontology(), input.bio_mode(), generation[0]
        if not selected:
            return error(ValueError("Select clinical terms in step 2 first."))
        enrich = input.mesh_enrichment()
        messages["match"].set("Matching source phrases…")
        async def work():
            result = await bp.annotate(text, ontology) if mode == "Live BioPortal" else demo_annotations(text, ontology)
            result = filter_tags(result, selected)
            # Search remaining source phrases; keep these as candidates, not exact lexical matches.
            if mode == "Live BioPortal":
                for term in selected:
                    if any(t["start"] < term["end"] and t["end"] > term["start"] for t in result):
                        continue
                    candidates = (await bp.search(term["phrase"], ontology)).get("collection", [])[:1]
                    for concept in candidates:
                        result.append(make_candidate(term, concept, ontology, "BioPortal search candidate · verify meaning"))
            if enrich:
                mesh = await bp.annotate(text, "MESH") if mode == "Live BioPortal" else demo_mesh_annotations(text)
                result.extend(filter_tags(mesh, selected))
            with reactive.isolate():
                if version != generation[0] or chosen_terms() != selected:
                    return
                clear_matches(); tags.set(result); update_tag_choices()
                messages["match"].set(f"{len(result)} candidate matches. Unmatched phrases remain visible below.")
        spawn("match", work)

    def make_candidate(term, concept, ontology, source):
        uri = concept["@id"]
        return {**term, "id": f'{uri}:{term["start"]}:{term["end"]}', "code": uri.rsplit("/", 1)[-1],
                "label": concept.get("prefLabel", uri), "uri": uri, "ontology": ontology, "source": source, "definitions": concept.get("definition", []), "synonyms": concept.get("synonym", [])}

    @render.text
    def match_status():
        return messages["match"]()

    @render.ui
    def highlighted():
        text, cursor, parts = input.note(), 0, []
        for tag in sorted(tags(), key=lambda t:(t["start"], -t["end"])):
            if tag["start"] < cursor:
                continue
            parts.extend([escape(text[cursor:tag["start"]]), "<mark>" + escape(text[tag["start"]:tag["end"]]) + "</mark>"])
            cursor = tag["end"]
        parts.append(escape(text[cursor:]))
        return ui.div(ui.HTML("".join(parts)), class_="clinical-text")

    @render.ui
    def matches():
        missing = [t["phrase"] for t in chosen_terms() if not any(t["start"] < p["end"] and t["end"] > p["start"] for p in tags() if p.get("ontology") != "MESH")]
        return ui.div(*[ui.div(ui.strong(t["phrase"] + " · " + t["ontology"] + " · " + t["code"]), ui.p(t["label"]), ui.tags.small(t["source"]), class_="tag-row") for t in tags()],
                      ui.p("No match yet: " + ", ".join(dict.fromkeys(missing))) if missing else ui.p("Every selected phrase has at least one candidate.") if terms() else ui.p("Select terms in step 2."))

    @reactive.effect
    @reactive.event(input.search)
    async def search():
        try:
            query, ontology, mode, version = input.query(), input.search_ontology(), input.bio_mode(), generation[0]
            if not query.strip():
                raise ValueError("Enter a term or code to search.")
            if mode == "Live BioPortal":
                items = (await bp.search(query, ontology)).get("collection", [])
            else:
                items = [{"@id": f"http://purl.bioontology.org/ontology/{ontology}/{c}", "prefLabel": label, "synonym": synonyms,
                          "definition": ["Offline teaching fixture"]} for c,label,synonyms in ([] if ontology == "MESH" else TERMS) if query.lower() in (c+label+" ".join(synonyms)).lower()]
            if version != generation[0]:
                return
            search_items.set(items); metadata.set(None)
            ui.update_select("concept", choices={c["@id"]: c.get("prefLabel", c["@id"]) for c in items})
            ui.notification_show(f"{len(items)} candidates found.")
        except (ValueError, httpx.HTTPError) as exc:
            error(exc)

    @reactive.effect
    @reactive.event(input.inspect)
    async def inspect():
        try:
            uri, relation, ontology, mode, version = input.concept(), input.relation(), input.search_ontology(), input.bio_mode(), generation[0]
            if not uri:
                raise ValueError("Search and choose a concept first.")
            result = await bp.explore(uri, ontology, relation) if mode == "Live BioPortal" else next((c for c in search_items() if c["@id"] == uri), {}) if not relation else {"message": "Live BioPortal is required for actual relationships and mappings."}
            if version == generation[0] and uri == input.concept() and relation == input.relation():
                metadata.set(result)
        except (ValueError, httpx.HTTPError) as exc:
            error(exc)

    @render.ui
    def concept_detail():
        return ui.tags.pre(json.dumps(metadata(), indent=2, ensure_ascii=False)) if metadata() is not None else ui.p("Inspect a candidate to see ontology details.")

    @reactive.effect
    @reactive.event(input.add_match)
    def add_match():
        term = next((t for t in chosen_terms() if t["id"] == input.search_term()), None)
        concept = next((c for c in search_items() if c["@id"] == input.concept()), None)
        if not term or not concept:
            return error(ValueError("Choose a source phrase and a search candidate."))
        candidate = make_candidate(term, concept, input.search_ontology(), "Reviewer-added " + input.bio_mode() + " search candidate")
        if any(t["id"] == candidate["id"] for t in tags()):
            return error(ValueError("This candidate is already in the review list."))
        tags.set(tags() + [candidate]); audit_snapshot.set(None); finalized.set(None); update_tag_choices(candidate["id"])
        ui.notification_show("Candidate added. Review it in step 4.")

    @render.text
    def review_progress():
        return f"{len(reviews())} of {len(tags())} matches reviewed"

    @render.ui
    def review_evidence():
        tag = next((t for t in tags() if t["id"] == input.tag()), None)
        if not tag:
            return ui.p("Match terms in step 3 first.")
        return ui.card(ui.h4(tag["code"] + " · " + tag["label"]), ui.p(tag["context"], class_="badge-note"),
                       ui.tags.blockquote(tag["evidence"]), ui.p("Source: " + tag["source"]),
                       ui.p("MeSH enrichment · accepting keeps this concept annotation; it does not add a diagnosis code." if tag["ontology"] == "MESH" else "Diagnosis candidate"),
                       ui.p("; ".join(tag.get("definitions", []))))

    @reactive.effect
    @reactive.event(input.tag)
    def restore_review():
        existing = reviews().get(input.tag(), {})
        ui.update_radio_buttons("decision", selected=existing.get("decision", "Needs clarification"))
        ui.update_text_area("feedback", value=existing.get("feedback", ""))
        ui.update_text("correction", value=existing.get("correction", ""))

    @reactive.effect
    @reactive.event(input.save_review)
    def save_review():
        if not any(t["id"] == input.tag() for t in tags()):
            return error(ValueError("Choose a current match."))
        if not input.feedback().strip():
            return error(ValueError("Add a short reason for this decision."))
        selected_tag = next(t for t in tags() if t["id"] == input.tag())
        if selected_tag["ontology"] == "MESH" and input.correction().strip():
            return error(ValueError("MeSH enrichment cannot be corrected to a diagnosis code. Clear the replacement field; reject an incorrect MeSH match."))
        updated = dict(reviews())
        updated[input.tag()] = {"decision": input.decision(), "feedback": input.feedback().strip(), "correction": input.correction().strip().upper(), "timestamp": datetime.now(timezone.utc).isoformat()}
        reviews.set(updated); finalized.set(None); audit_snapshot.set(None)
        ui.update_checkbox("audit_ack", value=False)
        remaining = [t["id"] for t in tags() if t["id"] not in updated]
        if remaining:
            ui.update_select("tag", selected=remaining[0])
        ui.notification_show("Decision saved." + (" All matches have feedback." if not remaining else ""))

    @render.ui
    def review_log():
        return ui.tags.details(ui.tags.summary("All match decisions"), *[ui.p(f'{t["phrase"]} · {t["code"]}: {reviews().get(t["id"], {}).get("decision", "Not reviewed")}') for t in tags()])

    @reactive.effect
    @reactive.event(input.audit)
    def audit():
        if not tags():
            return error(ValueError("Match terms before running the agent audit."))
        if len(reviews()) != len(tags()):
            return error(ValueError("Save feedback for every match in step 4 first."))
        text, current_tags, current_reviews, final_candidates = input.note(), tags(), reviews(), coded_rows()
        saved, demo, prompt = snapshot(), input.ai_mode() == "Demo rules", prompts[4]()
        audit_rows.set({}); audit_summary.set(""); audit_snapshot.set(None); finalized.set(None)
        ui.update_checkbox("audit_ack", value=False)
        messages["audit"].set(f"Checking 0 of {len(current_tags)} matches…")
        async def work():
            rows = {}
            for i, tag in enumerate(current_tags):
                result = await audit_tag(text, tag, current_reviews.get(tag["id"], {}), prompt, demo)
                with reactive.isolate():
                    if snapshot() != saved:
                        messages["audit"].set("The visit or feedback changed. Run the audit again.")
                        return
                    rows[tag["id"]] = result
                    audit_rows.set(dict(rows))
                    messages["audit"].set(f'Checked {i+1} of {len(current_tags)} · {tag["phrase"]}')
            summary = "Demo list checks only; no model inference." if demo else await audit_list(text, current_tags, current_reviews, rows, final_candidates, prompt)
            with reactive.isolate():
                if snapshot() != saved:
                    messages["audit"].set("The visit changed. Run the audit again.")
                    return
                audit_summary.set(summary); audit_snapshot.set(saved)
                messages["audit"].set(f"Audit complete · {len(rows)} of {len(current_tags)} matches checked, plus list review.")
        spawn("audit", work)

    @render.text
    def audit_status():
        stale = audit_rows() and audit_snapshot() != snapshot()
        return "Audit is incomplete or out of date. Run it again." if stale and "audit" not in running else messages["audit"]()

    @render.ui
    def audit_output():
        return ui.div(*[ui.div(ui.strong(t["phrase"] + " · " + t["ontology"] + " · " + t["code"] + " · " + audit_rows()[t["id"]]["recommendation"]),
                ui.p(audit_rows()[t["id"]]["reason"]), ui.p("Your decision: " + reviews().get(t["id"], {}).get("decision", "Pending")), class_="tag-row") for t in tags() if t["id"] in audit_rows()],
                ui.h4("Whole-list checks"), *[ui.p(f) for f in list_checks(tags(), reviews(), chosen_terms())],
                ui.p("Current accepted visit codes: " + (", ".join(r["code"] for r in coded_rows()) or "None")),
                ui.h4("Agent list review · advisory"),
                ui.div(audit_summary().get("summary", ""), *[ui.p(issue["explanation"]) for issue in audit_summary().get("issues", [])], class_="chat-text") if isinstance(audit_summary(), dict) else ui.div(audit_summary(), class_="chat-text"))

    def coded_rows():
        return final_codes(tags(), reviews(), input.visit_date(), input.ontology())

    @reactive.effect
    def code_choices():
        rows = coded_rows()
        ui.update_select("first_code", choices={"": "Choose the first-listed diagnosis", **{r["code"]: r["code"] + " · " + r["description"] for r in rows}}, selected="")

    def blockers():
        issues = []
        rows = coded_rows()
        if not rows:
            issues.append("No accepted diagnosis codes.")
        if any(t["id"] not in reviews() for t in tags()):
            issues.append("Some matches still need your feedback.")
        if any(r["decision"] == "Needs clarification" for r in reviews().values()):
            issues.append("Clarification decisions remain unresolved.")
        if any(not r["validation"]["valid"] for r in rows):
            issues.append("Some codes need correction or a supported encounter date.")
        if audit_snapshot() != snapshot() or not input.audit_ack():
            issues.append("Run the current agent audit and acknowledge its findings.")
        if input.first_code() not in [r["code"] for r in rows]:
            issues.append("Choose a first-listed diagnosis.")
        if not input.coder_confirm():
            issues.append("Confirm your final documentation and code-order review.")
        if not input.unmatched_ack():
            issues.append("Check unmatched phrases in step 4 and confirm any missing diagnosis matches were addressed.")
        return issues

    @render.ui
    def coded_visit():
        rows = sorted(coded_rows(), key=lambda r:r["code"] != input.first_code())
        issues = blockers()
        return ui.div(ui.p("Needs clarification" if any(r["decision"] == "Needs clarification" for r in reviews().values()) else "Draft" if issues or finalized() != completion_snapshot() else "Review complete", class_="badge-note"),
            ui.p("Encounter: " + str(input.visit_date()) + " · Outpatient diagnosis codes · ICD-10-CM FY2027"),
            *[ui.card(ui.h4(("First-listed · " if r["code"] == input.first_code() else "Additional · ") + r["code"] + " · " + r["description"]),
                ui.p(r["validation"]["message"]), *[ui.tags.blockquote(e) for e in dict.fromkeys(r["evidence"])]) for r in rows],
            ui.tags.details(ui.tags.summary("Excluded matches"), *[ui.p(t["code"] + " · " + t["phrase"] + ": " + reviews()[t["id"]]["feedback"]) for t in tags() if reviews().get(t["id"], {}).get("decision") == "Reject"]),
            ui.tags.details(ui.tags.summary("Unmatched phrases"), *[ui.p(f) for f in list_checks(tags(), reviews(), chosen_terms()) if f.startswith("No code match")]),
            ui.div(ui.h4("Before completing"), *[ui.p(i) for i in issues]) if issues else ui.p("All workflow review checks are satisfied."),
            ui.p("Code-file checks confirm complete code identifiers for the date. Clinical appropriateness, sequencing instructions and reportability still require coder review. Procedure and service billing codes are outside this demo."),
            ui.a("Official code set and guidelines", href="https://www.cms.gov/medicare/coding-billing/icd-10-codes", target="_blank"))

    def completion_snapshot():
        return (snapshot(), input.first_code(), input.audit_ack(), input.coder_confirm(), input.unmatched_ack(), input.coder_name(), input.visit_comment())

    @reactive.effect
    @reactive.event(input.finalize)
    def finalize():
        issues = blockers()
        if issues:
            messages["final"].set("Resolve the items above before marking the review complete.")
        else:
            finalized.set(completion_snapshot()); messages["final"].set("Visit review complete. Export the reviewed codes and audit trail.")

    @render.text
    def final_status():
        if finalized() is None:
            return messages["final"]() if messages["final"]().startswith("Resolve") else ""
        return messages["final"]() if finalized() == completion_snapshot() else "Visit changed. Review and complete it again."

    def workspace(index):
        return {"step": STEPS[index], "synthetic_text": input.note(), "encounter_date": str(input.visit_date()), "ontology": input.ontology(),
                "mode": input.bio_mode(), "mesh_enrichment": input.mesh_enrichment(), "terms": chosen_terms(), "tags": tags(), "reviews": reviews(),
                "selected_tag": next((t for t in tags() if t["id"] == input.tag()), None),
                "concept_metadata": metadata(), "audit": audit_rows(), "list_audit": audit_summary(), "coded_visit": coded_rows()}

    @render.download(filename="synthetic-patient.txt")
    def patient_download():
        yield input.note()

    @render.download(filename="prompt-comparison-evidence.json")
    def comparison_download():
        if not COMPARISON_PATH.exists():
            raise ValueError("Run the local prompt comparison to generate evidence first.")
        yield COMPARISON_PATH.read_text(encoding="utf-8")

    @reactive.calc
    def export_snapshot():
        return build_outputs(text=input.note(), encounter_date=input.visit_date(), ontology=input.ontology(),
            matching_mode=input.bio_mode(), terms=chosen_terms(), tags=tags(), reviews=reviews(), audit=audit_rows(),
            list_audit=audit_summary(), audit_current=audit_snapshot() == snapshot(), first_listed=input.first_code(),
            finalized=finalized() == completion_snapshot(), blockers=blockers(),
            acknowledgements={"agent_findings": bool(input.audit_ack()), "unmatched_terms": bool(input.unmatched_ack()), "final_coder_review": bool(input.coder_confirm())},
            coder_name=input.coder_name(), visit_comment=input.visit_comment(), model=LOCAL_MODEL if input.ai_mode().startswith("Local") else "Demo rules")

    @render.ui
    def export_summary():
        if not input.note().strip():
            return ui.p("Add a patient file to generate outputs.")
        data = export_snapshot()["patient_encoding"]
        return ui.div(ui.p(data["review"]["status"].replace("_", " ").title(), class_="badge-note"),
            ui.p(f'{data["counts"]["diagnosis_codes"]} diagnosis codes · {data["counts"]["matched_occurrences"]} match decisions · coder feedback included'),
            ui.p("Package: patient encoding JSON, coder feedback JSON, printable HTML report, codes CSV and file manifest."),
            ui.p("Open the report in a browser and choose Print / save PDF."))

    @render.text
    def encoding_preview():
        if not input.note().strip():
            return "Add a patient file first."
        return json.dumps(export_snapshot()["patient_encoding"], indent=2, ensure_ascii=False)

    @render.text
    def feedback_preview():
        if not input.note().strip():
            return "Add a patient file first."
        return json.dumps(export_snapshot()["coder_feedback"], indent=2, ensure_ascii=False)

    @render.download(filename="patient_encoding.json")
    def audit_download():
        yield json.dumps(export_snapshot()["patient_encoding"], indent=2, ensure_ascii=False)

    @render.download(filename="coder_feedback.json")
    def feedback_download():
        yield json.dumps(export_snapshot()["coder_feedback"], indent=2, ensure_ascii=False)

    @render.download(filename="visit_report.html", media_type="text/html")
    def report_download():
        yield render_report(export_snapshot())

    @reactive.effect
    @reactive.event(input.preview_report)
    def preview_report():
        if not input.note().strip():
            return error(ValueError("Add a patient file before generating a report."))
        ui.modal_show(ui.modal(ui.tags.iframe(srcdoc=render_report(export_snapshot()), title="Visit coding report",
            sandbox="allow-scripts allow-modals", style="width:100%;height:72vh;border:0;background:white", id="report_frame"),
            title="Visit coding report", size="xl", easy_close=True, footer=ui.modal_button("Close report")))

    @render.download(filename="codeflow-output-package.zip", media_type="application/zip")
    def package_download():
        yield output_package(export_snapshot())

    @render.download(filename="codeflow-codes.csv")
    def codes_download():
        yield codes_csv(export_snapshot())

    @reactive.effect
    @reactive.event(input.save_prompt)
    def save_prompt():
        index, text = editing_prompt(), input.agent_prompt().strip()
        if index is None:
            return
        if not text or len(text) > 8000:
            return error(ValueError("Use 1–8,000 characters for the agent prompt."))
        prompts[index].set(text); chats[index].set([])
        if index == 4:
            audit_snapshot.set(None); finalized.set(None)
        ui.modal_remove()

    @reactive.effect
    @reactive.event(input.reset_prompt)
    def reset_prompt():
        if editing_prompt() is not None:
            ui.update_text_area("agent_prompt", value=PROMPTS[editing_prompt()])

    def bind_step(index):
        if index < 5:
            @reactive.effect
            @reactive.event(input[f"next_{index}"])
            def forward():
                if index == 1 and not chosen_terms():
                    return error(ValueError("Extract and select terms first."))
                if index == 2 and not tags():
                    return error(ValueError("Match selected terms first."))
                if index == 3 and len(reviews()) != len(tags()):
                    return error(ValueError("Save feedback for each match first."))
                ui.update_navset("workflow", selected=str(index+1))
        if index:
            @reactive.effect
            @reactive.event(input[f"back_{index}"])
            def back():
                ui.update_navset("workflow", selected=str(index-1))

        @reactive.effect
        @reactive.event(input[f"prompt_{index}"])
        def prompt_popup():
            editing_prompt.set(index)
            ui.modal_show(ui.modal(ui.input_text_area("agent_prompt", "Instructions", prompts[index](), rows=10, width="100%"),
                ui.p("Prompt edits apply to this session. Extraction and audit keep their required JSON output format."),
                title=STEPS[index] + " · Agent prompt", size="l", easy_close=True,
                footer=ui.div(ui.input_action_button("reset_prompt", "Restore default"), ui.modal_button("Cancel"), ui.input_action_button("save_prompt", "Save prompt", class_="btn-primary"))))

        @reactive.effect
        @reactive.event(input[f"clear_{index}"])
        def clear_chat():
            chats[index].set([])

        @reactive.effect
        @reactive.event(input[f"explain_{index}"], input[f"send_{index}"])
        def chat():
            data, prompt, history = workspace(index), prompts[index](), chats[index]()
            question = input[f"question_{index}"]().strip() or "Explain this step and the current results using the source evidence."
            version = generation[0]
            chat_status[index].set("Generating locally…")
            async def work():
                # Chat remains prose even when the tab's main action expects structured output.
                result = await local_assist(prompt + "\nFor this conversation, answer in plain language rather than JSON.", data, history, question)
                with reactive.isolate():
                    if generation[0] == version and workspace(index) == data and prompts[index]() == prompt:
                        chats[index].set(history + [{"role": "user", "content": question}, {"role": "assistant", "content": result}])
                        ui.update_text_area(f"question_{index}", value="")
                        chat_status[index].set("Answered locally · " + LOCAL_MODEL)
                    else:
                        chat_status[index].set("Context changed. Ask again.")
            spawn(f"chat-{index}", work)

        @render.ui
        def chat_output():
            return ui.div(ui.p(chat_status[index]()), *[ui.div(ui.strong("You" if m["role"] == "user" else "Assistant"), ui.div(m["content"], class_="chat-text"), class_="chat-"+m["role"]) for m in chats[index]()])
        output(chat_output, id=f"chat_{index}")

        @render.text
        def context_output():
            return json.dumps(workspace(index), indent=2, ensure_ascii=False)
        output(context_output, id=f"context_{index}")

    for index in range(6):
        bind_step(index)

app = App(app_ui, server, static_assets=Path(__file__).parent / "www")
