"""Run with uv run main.py from the extracted CodeFlow folder."""
import os
from pathlib import Path
import threading
import time
import urllib.request
import webbrowser
from shiny import run_app

def main():
    root = Path(__file__).resolve().parent
    if not (root / "app.py").is_file():
        raise SystemExit("Missing app.py. Extract the complete ZIP before starting.")
    port = int(os.environ.get("CODEFLOW_PORT", "8765"))
    if not 1024 <= port <= 65535:
        raise SystemExit("CODEFLOW_PORT must be between 1024 and 65535.")
    url = f"http://127.0.0.1:{port}"
    def open_when_ready():
        for _ in range(90):
            try:
                with urllib.request.urlopen(url, timeout=1) as response:
                    if response.status == 200:
                        webbrowser.open(url)
                        return
            except OSError:
                time.sleep(1)
    if os.environ.get("CODEFLOW_NO_BROWSER") != "1":
        threading.Thread(target=open_when_ready, daemon=True).start()
    print(f"CodeFlow: {url}\nKeep this console open. Press Ctrl+C to stop.", flush=True)
    run_app(str(root / "app.py"), host="127.0.0.1", port=port, launch_browser=False)

if __name__ == "__main__":
    main()
