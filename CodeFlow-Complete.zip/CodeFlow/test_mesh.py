import unittest
from engine import CASES, demo_mesh_annotations, BioPortal
from pipeline import final_codes, filter_tags, grounded_terms
from exports import build_outputs, render_report, codes_csv
from test_exports import sample

class MeshTests(unittest.IsolatedAsyncioTestCase):
    def test_mesh_review_export_separation(self):
        args = sample()
        mesh = demo_mesh_annotations(args['text'])
        self.assertTrue(mesh)
        args['tags'] += mesh
        for tag in mesh:
            args['reviews'][tag['id']] = dict(decision='Accept', feedback='Useful biomedical topic', correction='')
            args['audit'][tag['id']] = dict(recommendation='Keep', reason='Enrichment only')
        outputs = build_outputs(**args)
        patient = outputs['patient_encoding']
        self.assertEqual([d['coding']['code'] for d in patient['diagnoses']], ['J20.9'])
        self.assertEqual(len(patient['biomedical_annotations']), len(mesh))
        self.assertTrue(patient['review']['review_complete'])
        self.assertNotIn('D001991', codes_csv(outputs))
        self.assertIn('Useful biomedical topic', render_report(outputs))
        self.assertEqual(patient['biomedical_annotations'][0]['annotation_role'], 'biomedical_enrichment')
        args['reviews'][mesh[0]['id']]['decision'] = 'Reject'
        rejected = build_outputs(**args)
        self.assertEqual(len(rejected['patient_encoding']['biomedical_annotations']), len(mesh)-1)
        self.assertEqual(len(rejected['coder_feedback']['annotation_reviews']), len(args['tags']))

    async def test_live_mesh_offsets_and_metadata(self):
        class FakePortal(BioPortal):
            async def request(self, path, params=None, post=False):
                if path == '/annotator':
                    self.assert_params = params
                    return [{'annotatedClass': {'@id': 'http://id.nlm.nih.gov/mesh/D001991'}, 'annotations': [{'from': 1, 'to': 10}]}]
                if '/classes/' in path:
                    return {'prefLabel': 'Bronchitis', 'definition': ['Test definition'], 'synonym': ['Test synonym']}
                return {}
        bp = FakePortal()
        tags = await bp.annotate('Bronchitis documented.', 'MESH')
        self.assertEqual(bp.assert_params['ontologies'], 'MESH')
        self.assertEqual(tags[0]['phrase'], 'Bronchitis')
        self.assertEqual(tags[0]['definitions'], ['Test definition'])
        self.assertEqual(tags[0]['ontology'], 'MESH')
        self.assertTrue(filter_tags(tags, grounded_terms('Bronchitis documented.', ['Bronchitis'], 'test')))

