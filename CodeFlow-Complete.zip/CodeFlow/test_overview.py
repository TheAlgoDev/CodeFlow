import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from overview import load_comparison, COMPARISON_PATH, METRICS

class OverviewTests(unittest.TestCase):
    def test_actual_comparison_keeps_notes_and_settings_constant(self):
        data = load_comparison()
        self.assertIsNotNone(data)
        self.assertEqual(len(data['cases']), 3)
        for case in data['cases']:
            self.assertEqual(set(case['runs']), {'initial', 'refined'})
            for run in case['runs'].values():
                self.assertTrue(run['response']['done'])
                self.assertNotEqual(run['response'].get('done_reason'), 'length')
                self.assertIn('started_at',run)

    def test_changed_source_is_rejected(self):
        data = json.loads(COMPARISON_PATH.read_text(encoding='utf-8'))
        data['cases'][0]['note'] += ' changed'
        with TemporaryDirectory() as temp:
            path=Path(temp)/'comparison.json'
            path.write_text(json.dumps(data),encoding='utf-8')
            with self.assertRaises(ValueError):
                load_comparison(path)

    def test_three_metrics_are_targets_without_claimed_results(self):
        self.assertEqual(len(METRICS), 3)
        for metric in METRICS:
            self.assertTrue(all(metric.get(k) for k in ['name','definition','target','measurement']))
            self.assertNotIn('achieved',metric)

if __name__ == '__main__':
    unittest.main()
