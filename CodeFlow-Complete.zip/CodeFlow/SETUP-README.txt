CODEFLOW - START HERE
====================
Windows 10/11. Extract the entire ZIP first (do not run inside the ZIP).
Open the extracted CodeFlow folder, right-click blank space, and choose Open in Terminal.
Run this one command in PowerShell:

    powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-CodeFlow.ps1

This execution-policy setting applies only to that process; it does not change system policy.
The script installs uv if missing through Windows Package Manager, downloads Python 3.12
if needed, installs locked dependencies, and offers optional Ollama/model setup.
It opens this README, the slides in PowerPoint (PDF fallback), and the app in your browser.
Keep the console open. Press Ctrl+C to stop the app. Browser address: http://127.0.0.1:8765
If another app uses that port, set $env:CODEFLOW_PORT = '8766' before starting.

FAST DEMO (skip optional local-model installation/download):
    powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-CodeFlow.ps1 -Demo

AFTER SETUP, THE SHORT COMMAND IS:
    uv run main.py

SETUP REQUIREMENTS
- Internet on first setup for uv, Python and dependencies. No admin is normally needed
  for user-scoped tools; Windows or organizational policies may require assistance.
- If winget is unavailable, install App Installer from Microsoft Store, or install uv:
  https://docs.astral.sh/uv/getting-started/installation/
- Optional local AI: Ollama (https://ollama.com/download/windows) and qwen3.5:2b.
  Model weights are NOT inside this ZIP; setup asks before downloading them separately.
  Ollama continues running after CodeFlow exits and can be quit separately.
- BioPortal: use your own key in the app's masked sidebar field, then click Connect.
  No account credentials are included. Live annotation sends synthetic text to BioPortal.
- Demo mode works without Ollama or a BioPortal account after Python setup.

FIRST VISIT
The automatic guided tour demonstrates all six steps using labeled scripted fixtures.
Close it or use Watch guided demo to replay it. For your own run:
1. Open a synthetic patient file.
2. Extract terms (local AI or demo rules in Settings).
3. Match codes. Optionally enable Enrich with MeSH biomedical concepts.
4. Save a reason for every accepted/rejected/questioned tag.
5. Run the agent audit and review its findings.
6. Review diagnosis codes, choose first-listed, confirm, and export the output package.
MeSH concepts are enrichment; they do not become diagnosis codes.
Use only synthetic data. This is an educational prototype, not a billing system.
Export your work before closing: session data is not permanently saved by the app.

PRESENTATION
presentation\CodeFlow.pptx - editable slides, including speaker notes
presentation\CodeFlow.pdf  - portable viewing copy
presentation\Google-Slides.url - original online deck (access depends on Google permissions)
CodeFlow-guided-walkthrough.mp4 - scripted 2 minute 47 second demo; no narration
The recorded model comparisons predate MeSH; targets are proposed, not measured results.
The video demonstrates the original six-stage workflow and does not show MeSH enrichment.

CONTENTS / VERIFICATION
README.md has technical details. Source, tests, synthetic examples, class references,
the bundled FY2027 ICD-10-CM code file, and actual prompt-comparison evidence are included.
MeSH JSON/report exports use schema 1.1.0. Older example exports may use schema 1.0.0.
To check setup without opening windows or starting the app:
    powershell -NoProfile -ExecutionPolicy Bypass -File .\Start-CodeFlow.ps1 -CheckOnly
No virtual environment, model weights, API keys or personal credentials are bundled.
MANIFEST.sha256 lists SHA-256 checksums of the delivered files.
