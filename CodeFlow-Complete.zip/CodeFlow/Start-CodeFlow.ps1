[CmdletBinding()]
param(
    [switch]$Demo,
    [switch]$SkipOpen,
    [switch]$CheckOnly
)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

function Refresh-UserPath {
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
}
function Install-UserTool([string]$Id) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        throw "Windows App Installer (winget) is needed. Install it from Microsoft Store, then rerun this script."
    }
    & winget install --id $Id --exact --source winget --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) { throw "Could not install $Id. Install it manually and rerun." }
    Refresh-UserPath
}
try {
    if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'app.py'))) {
        throw 'Extract the complete ZIP, then run the script inside the extracted CodeFlow folder.'
    }
    Write-Host 'CodeFlow setup: Python dependencies, optional local AI, and presentation.' -ForegroundColor Cyan
    if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
        Write-Host 'Installing uv using Windows Package Manager...'
        Install-UserTool 'astral-sh.uv'
    }
    if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
        throw 'uv is not on PATH yet. Close and reopen PowerShell, then rerun this script.'
    }
    & uv sync --locked --python 3.12
    if ($LASTEXITCODE -ne 0) { throw 'Dependency setup failed. Check internet access and retry.' }
    if ($CheckOnly) {
        & uv run --locked python -m unittest discover -p 'test_*.py'
        if ($LASTEXITCODE -ne 0) { throw 'Self-checks failed.' }
        Write-Host 'Setup and self-checks passed.' -ForegroundColor Green
        exit 0
    }
    if (-not $Demo) {
        if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
            $installAI = Read-Host 'Install Ollama for local AI? This is optional; N uses demo rules [y/N]'
            if ($installAI -match '^[Yy]') { Install-UserTool 'Ollama.Ollama' } else { $Demo = $true }
        }
        if (-not $Demo -and (Get-Command ollama -ErrorAction SilentlyContinue)) {
            try { $null = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 3 }
            catch {
                Start-Process -FilePath (Get-Command ollama).Source -ArgumentList 'serve' -WindowStyle Hidden
                Start-Sleep -Seconds 3
            }
            $model = if ($env:OLLAMA_MODEL) { $env:OLLAMA_MODEL } else { 'qwen3.5:2b' }
            try {
                $models = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 5
                if ($model -notin @($models.models.name)) {
                    $pull = Read-Host "Download $model for local AI (separate multi-GB download)? N uses demo rules [y/N]"
                    if ($pull -match '^[Yy]') {
                        & ollama pull $model
                        if ($LASTEXITCODE -ne 0) { throw 'Model download failed.' }
                    } else { $Demo = $true }
                }
            } catch {
                Write-Host 'Local AI is unavailable. Starting with demo rules; check Ollama later.' -ForegroundColor Yellow
                $Demo = $true
            }
        } else { $Demo = $true }
    }
    if ($Demo) { $env:CODEFLOW_DEMO = '1' } else { Remove-Item Env:CODEFLOW_DEMO -ErrorAction SilentlyContinue }
    if (-not $SkipOpen) {
        Start-Process -FilePath notepad.exe -ArgumentList ('"' + (Join-Path $PSScriptRoot 'SETUP-README.txt') + '"')
        $deck = Join-Path $PSScriptRoot 'presentation\CodeFlow.pptx'
        $powerPointCommand = Get-Command POWERPNT.EXE -ErrorAction SilentlyContinue
        $powerPoint = if ($powerPointCommand) { $powerPointCommand.Source } else { $null }
        if (-not $powerPoint) {
            foreach ($officeRoot in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
                if ($officeRoot) {
                    $candidate = Join-Path $officeRoot 'Microsoft Office\root\Office16\POWERPNT.EXE'
                    if (Test-Path -LiteralPath $candidate) { $powerPoint = $candidate; break }
                }
            }
        }
        try {
            if ($powerPoint) { Start-Process -FilePath $powerPoint -ArgumentList ('"' + $deck + '"') }
            else { Start-Process -FilePath (Join-Path $PSScriptRoot 'presentation\CodeFlow.pdf') }
        } catch { Start-Process -FilePath (Join-Path $PSScriptRoot 'presentation\CodeFlow.pdf') }
    } else { $env:CODEFLOW_NO_BROWSER = '1' }
    Write-Host 'Starting CodeFlow. Enter your own BioPortal key in the app for live access.' -ForegroundColor Green
    & uv run --locked main.py
    if ($LASTEXITCODE -ne 0) { throw 'CodeFlow stopped with an error. Check whether port 8765 is already in use.' }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
