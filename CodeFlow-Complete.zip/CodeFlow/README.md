# CodeFlow

A simple six-step Shiny for Python workflow for synthetic outpatient diagnosis coding.

## Presenter overview

The first tab, **Overview**, provides brief problem/workflow/human-review bullets, a side-by-side prompt comparison and three proposed success metrics. **Brief presenter view** is on by default: it shows one focus example and compact metric targets. Turn it off to see all three comparisons and inline metric definitions. The six workflow stages retain their original numbering. Expand details for full prompts, source notes, unedited model outputs or measurement methods.

`data/prompt-comparison.json` records six actual local `qwen3.5:2b` responses: an initial and refined prompt for each of the same three synthetic notes. Both versions use identical model settings, system instructions and JSON output schema. Requests, unedited responses, timestamps, source hashes and model details are retained and downloadable. These are illustrative runs, not expert-validated accuracy results or a held-out evaluation.

The Overview labels all metric targets as **proposed, not measured or achieved**: coding precision ≥90%, unsupported visit-code suggestions ≤0.1 per visit, and active coder-review time reduced ≥20% versus manual review. Definitions and measurement plans are included. Tagged contextual mentions must not be counted automatically as proposed diagnoses. Agree on targets before an independent evaluation.

To regenerate the evidence explicitly, run `.venv/Scripts/python.exe run_prompt_comparison.py` while Ollama is running, then restart Shiny. This overwrites the comparison artifact with six new real responses; it does not edit the recorded outputs manually.

## Start

```powershell
uv venv .venv --python 3.12
uv pip install --python .venv/Scripts/python.exe -r requirements.txt
.venv/Scripts/python.exe -m shiny run app.py --host 127.0.0.1 --port 8765
```

Open http://127.0.0.1:8765. The local environment already has dependencies installed. Start Ollama with the installed `qwen3.5:2b` model before running extraction, conversations, or the agent audit. On another computer, install Ollama and run `ollama pull qwen3.5:2b`. `OLLAMA_MODEL` can override the model before Shiny starts.

## Walk through one visit

1. **Patient file** — Read the synthetic chart. Select another teaching case and click Open patient file, or expand Edit or import synthetic text to paste or import a UTF-8 `.txt` file. Set the encounter date there. Download a sample patient file if useful.
2. **Extract terms** — Click Extract terms. The local model proposes exact phrases, then the app discards anything absent from the source. Select the phrases to match. Add a missed phrase by copying it from the chart. Extraction can miss relevant information; inspect the source evidence.
3. **Match codes** — Click Match selected terms. Live BioPortal annotates the original text and retains matches overlapping the selected terms. It searches unmatched phrases for a candidate when annotation finds nothing. Search candidates are explicitly labeled for meaning review. Expand Find or refine a match to search alternatives, inspect synonyms, definitions, parents, children and mappings, and add a candidate for a selected source occurrence. Extra alternatives are separate review items; reject the ones you do not use.
4. **Your review** — Review each occurrence, choose Accept, Reject or Needs clarification, explain why, and Save and review next. Expand Correct the code to provide a replacement; accepted replacements appear in the final visit and are checked against the official code file. Review unmatched phrases and confirm you addressed any missing diagnosis matches.
5. **Agent audit** — Click Check all tags. The local model loops over every tag with your feedback, showing progress and a recommendation for each. It then reviews the entire list. Deterministic checks also flag duplicate codes, mixed context, questionable acceptance and unmatched terms. Recommendations never overwrite your decisions. Return to review to correct anything; rerun the audit after a change. Acknowledge findings when resolved or documented.
6. **Coded visit** — View a consolidated diagnosis list with official descriptions, source evidence, exclusions and code validity. Choose the first-listed diagnosis after considering sequencing rules, add overall coder feedback if useful, confirm your review and Mark review complete. The app blocks completion for unresolved reviews, incomplete code identifiers, an unsupported encounter date, missing current audit, or missing confirmations. Click **Download output package** for the encoding JSON, coder feedback JSON, HTML report, codes CSV and checksum manifest. Drafts can be exported with their actual status and outstanding items.

Each step has Back and Continue buttons. You can also use the six tabs directly. The sidebar keeps a collapsible patient file available throughout. Settings, conversations, prompt editors and detailed ontology exploration stay out of the main path.

## First-run presentation and guidance

The first visit in a browser automatically opens a slow guided demonstration. It runs in a **separate Shiny session inside an overlay**, so it does not change the working patient file, coder feedback or session BioPortal key. It uses the Medication trap synthetic case, demo extraction/matching rules and demo audit results. A persistent banner labels it as scripted; it makes no live BioPortal or local-model requests.

The tour clicks through all six stages, fills five example coder decisions with rationales, runs the demo audit, consolidates the final diagnosis code, shows the patient encoding JSON and previews the printable report. The example coder is labeled "Presentation demo (scripted)". This demonstrates the workflow, not model accuracy or live service availability.

Use **Pause / Play**, **Next**, or **Skip tour**. **Use my workspace** returns to the unchanged working session. **Watch guided demo** in the sidebar replays it. After completion or exit, local browser storage remembers that onboarding was shown for this app origin. Clearing browser site data resets this preference. Browser sessions and ports have their own site storage.

Every stage also has a **How this step works** popup covering its purpose, required action and result. Close it with **Got it** or Escape. **Preview report** opens the report in-app without downloading a file.

`CodeFlow-guided-walkthrough.mp4` is a 2 minute 47 second recording of the actual automated demonstration, with readable on-screen explanations and no narration. It was captured from the browser at two frames per second and encoded as a 1600×900 H.264 MP4 at 30 fps for playback. The recording preserves the slow reading pace; it is a scripted demo, not a live model/API run.

For a presentation, use a fresh browser/app origin to see the automatic tour or click Watch guided demo. Allow roughly three minutes. The public query `?tour=1` opens the isolated demonstration directly; `?tour=1&autostart=0` opens it paused for recording or rehearsal.

## Assistant interaction

Expand Ask the local assistant on any tab to ask follow-ups, request an explanation, edit that tab's prompt in a popup, or clear chat. The model receives the current patient source, selected phrases, matches, feedback, selected tag, concept metadata, audit results and final code candidates. Recent conversation turns are included. View context shows the payload.

Extraction and audit use structured JSON output with validation. Prompt customization changes the task instructions but preserves those output contracts. Prompt edits and conversations are session-only. The new coding output package includes agent recommendations and model provenance, but excludes raw chat, editable prompts and connection credentials. The model can still produce unsupported explanations; the app does not establish medical coding correctness from model output.

## Patient encoding, coder feedback and report

The final page creates one cached export snapshot shared by all download formats. The snapshot updates when source data, coding decisions, feedback, confirmations or completion state change. Each export has a schema version (`1.0.0`), a stable source/date-based visit ID, a content-based record version, an export ID and a UTC timestamp. The current files are app-specific structured JSON, not FHIR resources or billing claims.

- `patient_encoding.json`: source patient file and hash, encounter context, ordered accepted diagnosis codes, explicit code system/version, official code-file validation, source spans, linked coder feedback for every supporting occurrence, unmatched phrases, status, confirmations, outstanding items and provenance.
- `coder_feedback.json`: every matched occurrence including rejected, unresolved and unreviewed items; original concept/code, effective code and any replacement, source evidence, saved coder rationale and timestamp, and the agent recommendation with its current/stale status. Feedback is the latest saved decision per occurrence, not a complete edit history.
- `visit_report.html`: a self-contained readable report covering codes, source evidence, coder decisions/rationales/corrections, exclusions, pending items, agent findings, source file and scope limits. Open it in a browser and choose **Print / save PDF**. PDF generation uses the browser print dialog; no PDF file is generated automatically.
- `codes.csv`: ordered accepted codes, validation status and coder rationale, with spreadsheet formula protection.
- `manifest.json`: file names and SHA-256 hashes to check package integrity.

Optional coder labels are self-reported and are not authenticated signatures. Changing the coder label or overall visit feedback after completion requires completing the review again. A correction to an unknown or incomplete code stays unvalidated; its description is not borrowed from the original code. Missing review decisions, stale/incomplete audit coverage, missing confirmations and code-validation failures prevent an export from claiming `review_complete` even if a caller requests it.

`example-output/` contains a generated teaching example from deterministic fixtures. Its reviewed label demonstrates workflow state, not expert validation or an actual user's signature. `exports.py` builds and checks all outputs from explicit fields, without reading API keys or environment credentials.

## BioPortal configuration

Enter your key in the masked **BioPortal API key** box in the workspace sidebar and click **Connect**. The app verifies ICD-10-CM access, clears the entry box and enables Live BioPortal without restarting. The connected key is held only in that browser session's server memory and is excluded from exports, assistant context and logs. Reloading or closing the session discards it. Connection changes clear old matches and downstream decisions.

Alternatively set `BIOPORTAL_API_KEY` in the server environment before starting Shiny. If configured, live BioPortal is the default. Otherwise the app defaults to clearly labeled Offline demo. Choose Term matching under sidebar Settings to switch modes.

Live annotation sends synthetic source text to BioPortal over HTTPS using an authorization header. Search and concept detail calls use the official REST API. Offline matching uses a tiny curated teaching vocabulary and does not fabricate actual ontology hierarchy or mappings. Live authenticated access must be verified with the user's account.

ICD-10-CM is the default for diagnosis coding. ICD-10 remains an exploration option, but final code validation requires ICD-10-CM. The local model uses only the loopback Ollama endpoint and needs no cloud AI key.

## Code validation and scope

The bundled official CMS FY2027 complete code list contains 74,879 diagnosis identifiers. The app checks existence, complete-code specificity and encounter date applicability from October 1, 2026 through September 30, 2027. It consolidates accepted duplicate codes and applies reviewer-entered replacements.

The code list does **not** implement tabular instructional notes, combination-code requirements, Excludes rules, all sequencing rules, payer edits or clinical reportability. Coder confirmation is still required. "Review complete" describes completion of this educational workflow, not billing certification. Procedures, CPT/HCPCS and service billing are outside scope.

State is session-only. Source, date, vocabulary or matching-service changes clear downstream work. Term changes clear matches. Feedback, code, prompt or assistant-mode changes invalidate relevant audit/final completion checks. An audit generated against an older snapshot cannot satisfy final completion. Export before closing or reloading.

## Validation

Run `.venv/Scripts/python.exe -m unittest -v` from this directory. Tests cover source spans, context flags, selection filtering, model request contracts, audit response validation, official complete-code/date checks, replacements and deduplication. Model output is not independently expert-validated.

## Files

- `app.py`: six-step UI, reactive workflow, review, conversations and exports.
- `pipeline.py`: source grounding, structured extraction/audit, list checks and final code validation.
- `exports.py`: versioned outputs, feedback links, report generation, CSV and ZIP package.
- `engine.py`: local model and BioPortal adapters plus teaching fixtures.
- `data/`: official code archive and provenance.
- `www/`: styling.
- `www/tour.js`, `www/tour.css`: isolated first-run demonstration, replay controls, highlighting and stage help.

References: https://data.bioontology.org/documentation and https://www.cms.gov/medicare/coding-billing/icd-10-codes

## Optional MeSH enrichment
In Match codes, enable Enrich with MeSH biomedical concepts before matching. Live BioPortal annotates the selected source phrases with MESH in addition to the coding vocabulary. Review every MeSH tag in Your review; accepting retains enrichment only. Use Search vocabulary to inspect MeSH definitions, synonyms, parents, children or mappings. Offline mode includes a clearly labeled Bronchitis fixture only; use live access for real relationships. Accepted concepts are in patient_encoding.json biomedical_annotations; all decisions remain in coder_feedback.json and the report. Diagnosis codes and codes.csv exclude MeSH. Schema version: 1.1.0.

