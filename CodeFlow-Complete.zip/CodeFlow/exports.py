"""Versioned patient encoding, linked coder feedback and a report from one snapshot."""
import csv
import hashlib
import io
import json
from datetime import datetime, timezone
from html import escape
from uuid import uuid4
from zipfile import ZipFile, ZIP_DEFLATED
from pipeline import final_codes, validate_code

SCHEMA_VERSION = "1.1.0"
SYSTEMS = {"ICD10CM": "http://hl7.org/fhir/sid/icd-10-cm", "ICD10": "http://hl7.org/fhir/sid/icd-10", "MESH": "http://id.nlm.nih.gov/mesh"}
LIMITATION = "Code-file checks confirm identifier existence, complete-code specificity and date applicability only. Clinical appropriateness, reportability, sequencing and payer rules require coder review. This is synthetic educational data, not a billing claim or FHIR resource."

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()

def coding(code, label, ontology):
    return {"code": str(code), "system": SYSTEMS.get(ontology), "ontology": ontology,
            "display": label, "version": "FY2027" if ontology == "ICD10CM" else None}

def source_mention(term, text):
    start, end = term.get("start"), term.get("end")
    if not isinstance(start, int) or not isinstance(end, int) or not 0 <= start < end <= len(text):
        raise ValueError("Cannot export an annotation with invalid source offsets.")
    phrase = text[start:end]
    if phrase != term.get("phrase"):
        raise ValueError("An annotation no longer matches the patient file. Run matching again.")
    return {"start": start, "end": end, "offset_convention": "zero-based, end-exclusive Unicode characters",
            "text": phrase, "context": term.get("context"), "evidence": term.get("evidence", "")}

def build_outputs(*, text, encounter_date, ontology, matching_mode, terms, tags, reviews,
                  audit, list_audit, audit_current, first_listed, finalized, blockers,
                  acknowledgements, coder_name="", visit_comment="", model=""):
    if not text or not text.strip():
        raise ValueError("Add a synthetic patient file before exporting.")
    if len({t["id"] for t in tags}) != len(tags):
        raise ValueError("Duplicate annotation identifiers prevent a reliable export.")
    tag_ids = {t["id"] for t in tags}
    if set(reviews) - tag_ids:
        raise ValueError("Coder feedback references annotations outside this visit.")
    date_text = str(encounter_date)
    visit_id = "visit-" + digest({"source": text, "date": date_text})[:16]
    author = {"display_name": coder_name.strip() or None, "identity_verified": False}
    review_rows = []
    for tag in tags:
        saved = reviews.get(tag["id"], {})
        decision = saved.get("decision", "Not reviewed")
        if decision not in ["Accept", "Reject", "Needs clarification", "Not reviewed"]:
            raise ValueError("Cannot export an unknown coder decision.")
        if saved and not str(saved.get("feedback", "")).strip():
            raise ValueError("A saved coder decision is missing its rationale.")
        original = coding(tag["code"], tag["label"], tag.get("ontology", ontology))
        correction = saved.get("correction", "").strip()
        is_mesh = tag.get("ontology") == "MESH"
        if is_mesh and correction:
            raise ValueError("MeSH annotations cannot use diagnosis-code corrections.")
        check = {"valid": None, "message": "MeSH enrichment; diagnosis-code validation does not apply."} if is_mesh else validate_code(correction or tag["code"], date_text, tag.get("ontology", ontology))
        effective = coding(check.get("code", correction or tag["code"]), check.get("description", "Unverified code description" if correction else tag["label"]), tag.get("ontology", ontology))
        review_rows.append({"review_id": "review-" + digest(tag["id"])[:16], "annotation_id": tag["id"],
            "source_mention": source_mention(tag, text), "original_coding": original,
            "original_concept_uri": tag.get("uri"), "match_provenance": tag.get("source"),
            "decision": decision, "rationale": saved.get("feedback") or None,
            "reviewed_at": saved.get("timestamp"), "coder": author,
            "replacement_coding": effective if correction else None,
            "effective_coding": effective, "code_validation": check,
            "included_in_patient_encoding": decision == "Accept",
            "annotation_role": "biomedical_enrichment" if is_mesh else "diagnosis_candidate",
            "included_in_diagnoses": decision == "Accept" and not is_mesh,
            "definitions": tag.get("definitions", []), "synonyms": tag.get("synonyms", []),
            "agent_recommendation": audit.get(tag["id"]), "agent_recommendation_current": bool(audit_current)})
    by_id = {r["annotation_id"]: r for r in review_rows}
    diagnoses = []
    rows = sorted(final_codes(tags, reviews, date_text, ontology), key=lambda row: row["code"] != first_listed)
    for position, row in enumerate(rows, 1):
        supporting_reviews = [by_id[tag_id] for tag_id in row["tag_ids"]]
        diagnoses.append({"encoding_id": "encoding-" + digest({"visit": visit_id, "ontology": ontology, "code": row["code"]})[:16],
            "order": position, "first_listed": row["code"] == first_listed,
            "coding": coding(row["code"], row["description"] if row["validation"]["valid"] else "Unverified code description", ontology),
            "validation": row["validation"], "annotation_ids": row["tag_ids"],
            "coder_feedback": supporting_reviews})
    unmatched = [dict(term_id=t["id"], **source_mention(t, text)) for t in terms
                 if not any(t["start"] < a["end"] and t["end"] > a["start"] for a in tags if a.get("ontology") != "MESH")]
    issues = list(dict.fromkeys(blockers))
    if not diagnoses:
        issues.append("No accepted diagnosis codes.")
    if any(r["decision"] in ["Needs clarification", "Not reviewed"] for r in review_rows):
        issues.append("Some annotation decisions are unresolved.")
    if any(not d["validation"]["valid"] for d in diagnoses):
        issues.append("Some accepted codes are not validated.")
    if diagnoses and sum(d["first_listed"] for d in diagnoses) != 1:
        issues.append("Select one first-listed diagnosis.")
    if not audit_current:
        issues.append("The agent audit is missing or out of date.")
    if set(audit) != tag_ids or not list_audit:
        issues.append("The agent audit does not cover the full list.")
    if not all(acknowledgements.get(k) for k in ["agent_findings", "unmatched_terms", "final_coder_review"]):
        issues.append("Required reviewer confirmations are incomplete.")
    issues = list(dict.fromkeys(issues))
    complete = bool(finalized and not issues)
    status = "review_complete" if complete else "needs_clarification" if any(r["decision"] == "Needs clarification" for r in review_rows) else "draft"
    state = {"status": status, "review_complete": complete, "outstanding_items": issues,
             "coder": author, "visit_comment": visit_comment.strip() or None, "acknowledgements": acknowledgements}
    counts = {"selected_terms": len(terms), "matched_occurrences": len(tags), "diagnosis_codes": len(diagnoses),
              "accepted_occurrences": sum(r["decision"] == "Accept" for r in review_rows),
              "rejected_occurrences": sum(r["decision"] == "Reject" for r in review_rows),
              "clarification_occurrences": sum(r["decision"] == "Needs clarification" for r in review_rows),
              "unreviewed_occurrences": sum(r["decision"] == "Not reviewed" for r in review_rows), "unmatched_terms": len(unmatched)}
    patient_label = next((line.split(":", 1)[1].strip() for line in text.splitlines() if line.lower().startswith("patient:")), "Synthetic patient")
    common = {"schema_version": SCHEMA_VERSION, "synthetic": True, "visit_id": visit_id,
        "encounter": {"date": date_text, "setting": "outpatient", "patient_label": patient_label},
        "review": state, "counts": counts, "limitations": LIMITATION}
    encoding = {**common, "document_type": "patient_encoding", "source": {"text": text, "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()},
        "diagnoses": diagnoses, "biomedical_annotations": [r for r in review_rows if r["original_coding"]["ontology"] == "MESH" and r["decision"] == "Accept"], "unmatched_terms": unmatched,
        "provenance": {"matching_mode": matching_mode, "coding_ontology": ontology, "local_model": model,
            "code_reference": {"publisher": "CMS", "version": "FY2027", "valid_from": "2026-10-01", "valid_through": "2027-09-30",
                               "url": "https://www.cms.gov/medicare/coding-billing/icd-10-codes"}}}
    feedback = {**common, "document_type": "coder_feedback", "annotation_reviews": review_rows,
        "agent_audit": {"current": bool(audit_current), "per_tag": audit, "whole_list": list_audit}}
    record_version = digest({"patient_encoding": encoding, "coder_feedback": feedback})
    export_meta = {"export_id": str(uuid4()), "record_version": record_version,
                   "generated_at": datetime.now(timezone.utc).isoformat()}
    encoding["export"] = feedback["export"] = export_meta
    outputs = {"patient_encoding": encoding, "coder_feedback": feedback}
    validate_outputs(outputs)
    return outputs

def validate_outputs(outputs):
    encoding, feedback = outputs["patient_encoding"], outputs["coder_feedback"]
    if any(encoding[k] != feedback[k] for k in ["visit_id", "schema_version", "export", "review", "counts"]):
        raise ValueError("Export documents do not describe the same visit revision.")
    review_map = {r["review_id"]: r for r in feedback["annotation_reviews"]}
    for diagnosis in encoding["diagnoses"]:
        if not isinstance(diagnosis["coding"]["code"], str):
            raise ValueError("Medical code identifiers must remain strings.")
        for review in diagnosis["coder_feedback"]:
            if review_map.get(review["review_id"]) != review or review["decision"] != "Accept":
                raise ValueError("An encoded diagnosis has inconsistent coder feedback.")
    return outputs

def render_report(outputs):
    validate_outputs(outputs)
    patient, feedback = outputs["patient_encoding"], outputs["coder_feedback"]
    def e(value):
        return escape(str(value if value is not None else "Not provided"))
    def table(headers, rows):
        return "<table><thead><tr>" + "".join("<th>"+e(h)+"</th>" for h in headers) + "</tr></thead><tbody>" + (
            "".join("<tr>"+"".join("<td>"+e(c)+"</td>" for c in row)+"</tr>" for row in rows) or f'<tr><td colspan="{len(headers)}">None</td></tr>') + "</tbody></table>"
    review = patient["review"]
    diagnoses = patient["diagnoses"]
    status_label = review["status"].replace("_", " ").title()
    blocks = ["<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>",
        "<title>CodeFlow · Visit coding report</title><style>body{font:16px/1.6 'Segoe UI',Arial,sans-serif;color:#18364a;background:#edf3f7;margin:0}main{max-width:1050px;margin:32px auto;padding:36px;background:white}h1{margin-bottom:0}h2{margin-top:32px;color:#087582}header{border-bottom:3px solid #087f8c;padding-bottom:20px}.badge{display:inline-block;padding:5px 12px;background:#e4f2f3;border-radius:5px;font-weight:600}table{width:100%;border-collapse:collapse;margin:16px 0;font-size:14px}th,td{padding:10px;border:1px solid #d5e0e7;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#edf4f7}pre,.text{white-space:pre-wrap;overflow-wrap:anywhere}blockquote{border-left:3px solid #8ba5b5;padding:10px 16px;margin-left:0;background:#f4f8fa}.metadata{color:#526b7b;font-size:14px}article{break-inside:avoid}button{padding:10px 18px;background:#087f8c;color:white;border:0;border-radius:5px;cursor:pointer}@media print{body{background:white}main{margin:0;padding:10px;max-width:none}.no-print{display:none}thead{display:table-header-group}tr{break-inside:avoid}h2{break-after:avoid}}@page{size:A4;margin:16mm}</style></head><body><main>",
        "<header><p>CODEFLOW · SYNTHETIC EDUCATIONAL DATA</p><h1>Visit coding report</h1>",
        f'<p class="badge">{e(status_label)}</p><p>{e(patient["encounter"]["patient_label"])} · {e(patient["encounter"]["date"])} · Outpatient</p>',
        f'<p class="metadata">Visit {e(patient["visit_id"])}<br>Export {e(patient["export"]["export_id"])}<br>Generated {e(patient["export"]["generated_at"])}<br>Schema {e(patient["schema_version"])} · Record version {e(patient["export"]["record_version"])}</p>',
        '<button class="no-print" onclick="window.print()">Print / save PDF</button></header>',
        "<h2>Coding summary</h2>", table(["Measure", "Count"], [(label.replace("_", " ").capitalize(), value) for label,value in patient["counts"].items()]),
        f'<p>Coder: {e(review["coder"]["display_name"])}. Name is self-reported; identity is not verified.</p>',
        f'<p class="text">Visit feedback: {e(review["visit_comment"])}</p>',
        "<h2>Encoded diagnoses</h2>"]
    if not diagnoses:
        blocks.append("<p>No accepted diagnosis codes. This report remains a draft.</p>")
    for diagnosis in diagnoses:
        code = diagnosis["coding"]
        blocks += [f'<article><h3>{e(diagnosis["order"])}. {e(code["code"])} · {e(code["display"])}</h3>',
            f'<p>{"First-listed" if diagnosis["first_listed"] else "Additional" if any(d["first_listed"] for d in diagnoses) else "Order awaiting confirmation"} · {e(code["ontology"])} · {e(code["version"])}<br>{e(diagnosis["validation"]["message"])}</p>']
        for item in diagnosis["coder_feedback"]:
            blocks.append(f'<blockquote>{e(item["source_mention"]["evidence"])}</blockquote><p class="text"><strong>Coder feedback:</strong> {e(item["rationale"])}</p>')
            if item["replacement_coding"]:
                blocks.append(f'<p>Coder corrected {e(item["original_coding"]["code"])} to {e(item["replacement_coding"]["code"])}.</p>')
        blocks.append("</article>")
    blocks += ["<h2>MeSH biomedical enrichment · separate from diagnosis codes</h2>", table(
        ["MeSH identifier", "Label", "Source evidence", "Coder feedback"],
        [(r["original_coding"]["code"], r["original_coding"]["display"], r["source_mention"]["evidence"], r["rationale"]) for r in patient.get("biomedical_annotations", [])]),
        "<h2>All matched terms and coder decisions</h2>", table(
        ["Source term / context", "Original code / system", "Decision / correction", "Coder rationale", "Reviewed at"],
        [(r["source_mention"]["text"] + " / " + (r["source_mention"]["context"] or "Unclear"),
          r["original_coding"]["code"] + " / " + r["original_coding"]["ontology"],
          r["decision"] + (" → " + r["replacement_coding"]["code"] if r["replacement_coding"] else ""), r["rationale"], r["reviewed_at"]) for r in feedback["annotation_reviews"]]),
        "<h2>Agent audit · advisory</h2>", f'<p>Current for this revision: {e(feedback["agent_audit"]["current"])}</p>', table(
            ["Term", "Recommendation", "Agent explanation"], [(r["source_mention"]["text"], (r["agent_recommendation"] or {}).get("recommendation", "Not available"),
                (r["agent_recommendation"] or {}).get("reason", "Not available")) for r in feedback["annotation_reviews"]])]
    whole = feedback["agent_audit"]["whole_list"]
    if isinstance(whole, dict):
        blocks.append(f'<p class="text">{e(whole.get("summary", ""))}</p>')
        blocks.extend(f'<p class="text">{e(issue.get("explanation", ""))}</p>' for issue in whole.get("issues", []))
    elif whole:
        blocks.append(f'<p class="text">{e(whole)}</p>')
    blocks += ["<h2>Unmatched phrases</h2>", table(["Term", "Context", "Source evidence"], [(t["text"], t["context"], t["evidence"]) for t in patient["unmatched_terms"]]),
        "<h2>Outstanding review items</h2>"]
    blocks.extend(f'<p>{e(item)}</p>' for item in review["outstanding_items"])
    if not review["outstanding_items"]:
        blocks.append("<p>No outstanding workflow checks. Finalization status is shown above.</p>")
    blocks += ["<h2>Reviewer confirmations</h2>", table(["Confirmation", "Acknowledged"], [(label.replace("_", " ").capitalize(), "Yes" if value else "No") for label,value in review["acknowledgements"].items()]),
        "<h2>Source patient file</h2>", f'<pre>{e(patient["source"]["text"])}</pre>',
        "<h2>Scope and provenance</h2>", f'<p>{e(patient["limitations"])}</p>',
        f'<p>Matching: {e(patient["provenance"]["matching_mode"])}. Local model: {e(patient["provenance"]["local_model"])}.</p>',
        '<p>Reference: <a href="https://www.cms.gov/medicare/coding-billing/icd-10-codes">Official CMS code files and guidelines</a>.</p>',
        "</main></body></html>"]
    return "".join(blocks)

def codes_csv(outputs):
    buffer = io.StringIO(); writer = csv.writer(buffer)
    writer.writerow(["code", "system", "description", "order", "first_listed", "code_file_valid", "coder_feedback", "review_status", "visit_id"])
    for diagnosis in outputs["patient_encoding"]["diagnoses"]:
        row = [diagnosis["coding"]["code"], diagnosis["coding"]["ontology"], diagnosis["coding"]["display"], str(diagnosis["order"]), str(diagnosis["first_listed"]),
               str(diagnosis["validation"]["valid"]), " | ".join(r["rationale"] or "" for r in diagnosis["coder_feedback"]), outputs["patient_encoding"]["review"]["status"], outputs["patient_encoding"]["visit_id"]]
        writer.writerow(["'" + value if value.startswith(("=", "+", "-", "@")) else value for value in row])
    return buffer.getvalue()

def output_package(outputs):
    validate_outputs(outputs)
    files = {"patient_encoding.json": json.dumps(outputs["patient_encoding"], indent=2, ensure_ascii=False),
             "coder_feedback.json": json.dumps(outputs["coder_feedback"], indent=2, ensure_ascii=False),
             "visit_report.html": render_report(outputs), "codes.csv": codes_csv(outputs)}
    files["manifest.json"] = json.dumps({"schema_version": SCHEMA_VERSION, "visit_id": outputs["patient_encoding"]["visit_id"],
        "export": outputs["patient_encoding"]["export"], "files": [{"name": name, "sha256": hashlib.sha256(value.encode("utf-8")).hexdigest()} for name,value in files.items()]}, indent=2)
    buffer = io.BytesIO()
    with ZipFile(buffer, "w", ZIP_DEFLATED) as archive:
        for name, value in files.items():
            archive.writestr(name, value.encode("utf-8"))
    return buffer.getvalue()
