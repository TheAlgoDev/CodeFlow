# Official code reference

`icd10cm-2027.zip` was downloaded from CMS:
https://www.cms.gov/files/zip/2027-code-descriptions-tabular-order.zip

Source listing: https://www.cms.gov/medicare/coding-billing/icd-10-codes

Downloaded 2026-11-23. Uses `Code Descriptions/icd10cm_codes_2027.txt` for complete diagnosis code identifiers and descriptions. Effective for encounters October 1, 2026 through September 30, 2027. Other encounter dates are explicitly unvalidated. Category-only identifiers do not pass this complete-code check.

This lookup does not implement tabular instruction rules, Excludes notes, clinical reportability, sequencing, or payer edits. Those require coder review against the official tabular/index and guidelines linked in the app.
